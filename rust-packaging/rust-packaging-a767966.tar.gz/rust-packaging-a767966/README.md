# rust-rpm-macros

Work-in-progress reorganization of the [rust2rpm] umbrella project into separate
projects to decouple development and distribution of these components:

- [cargo2rpm]: low-level cargo <-> RPM translation layer
- [rust-packaging]: RPM macros and dependency generators for building Rust packages
- [rust2rpm]: RPM spec file generator for Rust crates (name TBD)

[rust2rpm]: https://pagure.io/fedora-rust/rust2rpm
[cargo2rpm]: https://pagure.io/fedora-rust/cargo2rpm
[rust-packaging]: https://pagure.io/fedora-rust/rust-packaging

