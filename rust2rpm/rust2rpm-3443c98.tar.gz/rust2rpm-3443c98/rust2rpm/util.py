import contextlib
import os
import sys
import shlex
import shutil
import subprocess
import requests

DEFAULT_EDITOR = "vi"


@contextlib.contextmanager
def remove_on_error(path):
    try:
        yield
    except:  # this is supposed to include ^C
        os.unlink(path)
        raise


@contextlib.contextmanager
def exit_on_common_errors():
    """Suppress tracebacks on common "expected" exceptions"""
    try:
        yield
    except requests.exceptions.HTTPError as e:
        sys.exit(f"Failed to download metadata: {e}")
    except subprocess.CalledProcessError as e:
        cmd = shlex.join(e.cmd)
        sys.exit(f"Subcommand failed with code {e.returncode}: {cmd}")
    except FileNotFoundError as e:
        sys.exit(str(e))


def detect_editor():
    terminal = os.getenv("TERM")
    terminal_is_dumb = not terminal or terminal == "dumb"
    editor = None
    if not terminal_is_dumb:
        editor = os.getenv("VISUAL")
    if not editor:
        editor = os.getenv("EDITOR")
    if not editor:
        if terminal_is_dumb:
            raise Exception("Terminal is dumb, but $EDITOR unset")
        editor = DEFAULT_EDITOR
    return editor


def detect_packager():
    # If we're forcing the fallback...
    if os.getenv("RUST2RPM_NO_DETECT_PACKAGER"):
        return None

    # If we're supplying packager identity through an environment variable...
    if packager := os.getenv("RUST2RPM_PACKAGER"):
        return packager

    # If we're detecting packager identity through rpmdev-packager...
    if rpmdev_packager := shutil.which("rpmdev-packager"):
        return subprocess.check_output(rpmdev_packager, text=True).strip()

    # If we're detecting packager identity through git configuration...
    if git := shutil.which("git"):
        name = subprocess.check_output([git, "config", "user.name"], text=True).strip()
        email = subprocess.check_output([git, "config", "user.email"], text=True).strip()
        return f"{name} <{email}>"

    return None
