import argparse
import ast
import configparser
import contextlib
from datetime import datetime, timezone
import difflib
import functools
import glob
import os
import pathlib
import re
import shutil
import sys
import tarfile
import tempfile
import subprocess

import requests
import tqdm

from . import cfg, licensing, generator, log, util
from .core.metadata import Metadata

XDG_CACHE_HOME = os.getenv("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
CACHEDIR = os.path.join(XDG_CACHE_HOME, "rust2rpm")
API_URL = "https://crates.io/api/v1/"
DIST_GIT_URL = "https://src.fedoraproject.org/api/0/"
LICENSES = re.compile(
    r"""
    COPYING(?:[.-].*)?|COPYRIGHT(?:[.-].*)?|
    EULA(?:[.-].*)?|[Ll]icen[cs]e|[Ll]icen[cs]e.*|
    (?:.*[.-])?(?:UN)?LICEN[CS]E(?:[.-].*)?|NOTICE(?:[.-].*)?|
    PATENTS(?:[.-].*)?|
    (?:agpl|l?gpl)[.-].*|CC-BY-.*|
    (?:AGPL|APACHE|BSD|GFDL|GNU|L?GPL|MIT|MPL|OFL)-.*[0-9].*
    """,
    re.VERBOSE,
)

# [target.'cfg(not(any(target_os="windows", target_os="macos")))'.dependencies]
# [target."cfg(windows)".dependencies.winapi]
# [target."cfg(target_arch = \"wasm32\")".dev-dependencies.wasm-bindgen-test]

TARGET_DEPENDENCY_LINE = re.compile(
    r"""
    ^ \[ target\.(?P<cfg>(?P<quote>['"])cfg\(.*\)(?P=quote))
    \.
    (?P<type> dependencies|build-dependencies|dev-dependencies)
    (?:\. (?P<feature>[a-zA-Z0-9_-]+) )?
    \] \s* $
    """,
    re.VERBOSE,
)


class NoVersionsError(Exception):
    pass


def sortify(func):
    """Return a sorted list from a generator"""

    def wrapper(*args, **kwargs):
        return sorted(func(*args, **kwargs))

    return functools.update_wrapper(wrapper, func)


def read_os_release():
    try:
        f = open("/etc/os-release")
    except FileNotFoundError:
        f = open("/usr/lib/os-release")

    for line in f:
        line = line.rstrip()
        if not line or line.startswith("#"):
            continue
        if m := re.match(r"([A-Z][A-Z_0-9]+)=(.*)", line):
            name, val = m.groups()
            if val and val[0] in "\"'":
                val = ast.literal_eval(val)
            yield name, val


def get_default_target():
    os_release = dict(read_os_release())
    os_id = os_release.get("ID")
    # ID_LIKE is a space-separated list of identifiers like ID
    os_like = os_release.get("ID_LIKE", "").split()

    # Order matters here!
    if "mageia" in (os_id, *os_like):
        return "mageia"
    elif "fedora" in (os_id, *os_like):
        return "fedora"
    elif "suse" in os_like:
        return "opensuse"
    else:
        return "plain"


def file_mtime(path):
    return datetime.fromtimestamp(os.stat(path).st_mtime, timezone.utc).isoformat()


def package_name_suffixed(name, suffix):
    joiner = "_" if suffix and name[-1].isdigit() else ""
    return "rust-" + name + joiner + (suffix or "")


def local_toml(toml, version):
    if os.path.isdir(toml):
        doc_files = get_doc_files(toml)
        license_files = get_license_files(toml)
        toml = os.path.join(toml, "Cargo.toml")
    else:
        doc_files = []
        license_files = []

    return toml, None, version, doc_files, license_files


def local_crate(crate, version):
    cratename, version = os.path.basename(crate)[:-6].rsplit("-", 1)
    return crate, cratename, version


def query_newest_version(crate) -> str:
    url = requests.compat.urljoin(API_URL, f"crates/{crate}/versions")
    req = requests.get(url, headers={"User-Agent": "rust2rpm"})
    req.raise_for_status()
    versions = req.json()["versions"]

    is_stable = lambda s: not re.search("alpha|beta|rc|pre", s["num"])
    is_not_yanked = lambda s: not s["yanked"]

    # return the most recent, non-yanked stable version

    is_not_yanked_and_stable = lambda s: is_stable(s) and is_not_yanked(s)
    not_yanked_and_stable = [*filter(is_not_yanked_and_stable, versions)]
    if len(not_yanked_and_stable) > 0:
        version = not_yanked_and_stable[0]["num"]
        return version

    # there are no non-yanked stable versions:
    # fall back to the latest pre-release

    not_yanked = [*filter(is_not_yanked, versions)]
    if len(not_yanked) > 0:
        version = not_yanked[0]["num"]
        log.warn(f"No stable versions available. Falling back to the latest pre-release version {version!r}.")
        return version

    # there are no non-yanked versions: fatal
    raise NoVersionsError()


def download(crate, version):
    if version is None:
        # Now we need to get latest version
        version = query_newest_version(crate)

    os.makedirs(CACHEDIR, exist_ok=True)
    cratef_base = f"{crate}-{version}.crate"
    cratef = os.path.join(CACHEDIR, cratef_base)
    if not os.path.isfile(cratef):
        url = requests.compat.urljoin(API_URL, f"crates/{crate}/{version}/download#")
        req = requests.get(url, stream=True, headers={"User-Agent": "rust2rpm"})
        req.raise_for_status()
        total = int(req.headers["Content-Length"])
        with util.remove_on_error(cratef), open(cratef, "wb") as f:
            for chunk in tqdm.tqdm(
                req.iter_content(),
                f"Downloading {cratef_base}",
                total=total,
                unit="B",
                unit_scale=True,
            ):
                f.write(chunk)
    return cratef, crate, version


@contextlib.contextmanager
def files_from_crate(cratef, crate, version):
    """Unpacks cratef and returns path to toml file, list of doc files, list of license files"""
    with tempfile.TemporaryDirectory() as tmpdir:
        target_dir = f"{tmpdir}/"
        with tarfile.open(cratef, "r") as archive:
            for n in archive.getnames():
                if not os.path.abspath(os.path.join(target_dir, n)).startswith(target_dir):
                    raise Exception("Unsafe filenames!")
            archive.extractall(target_dir)
        toml = f"{tmpdir}/{crate}-{version}/Cargo.toml"
        if not os.path.isfile(toml):
            raise IOError("crate does not contain Cargo.toml file")
        root_path = f"{tmpdir}/{crate}-{version}"
        doc_files = get_doc_files(root_path)
        license_files = get_license_files(root_path)
        yield toml, doc_files, license_files


def filter_out_features_re(dropped_features):
    # This is a bit simplistic. But it doesn't seem worth the trouble to write
    # a grammar for this. Can be always done later. If we parse this using a
    # grammar, we beget the question how to preserve formatting idiosyncrasies.
    # Regexp replacement makes it trivial to minimize changes.
    match_features = "|".join(dropped_features)
    match_suffix = f"(?:/[{cfg.IDENT_CHARS[1]}]+)?"

    return re.compile(
        rf"""
        (?P<comma> ,)? \s* (?P<quote>['"])
        ({match_features}) {match_suffix}
        (?P=quote) \s* (?(comma) |,?) \s*
        """,
        re.VERBOSE,
    )


def drop_foreign_dependencies(lines):
    dropped_lines = 0
    dropped_optional_deps = set()
    good_lines = []

    keep = True
    feature = None
    for line in lines:
        if m := TARGET_DEPENDENCY_LINE.match(line):
            expr = m.group("cfg")
            expr = ast.literal_eval(expr)
            try:
                keep = cfg.parse_and_evaluate(expr)
            except (ValueError, cfg.ParseException):
                log.warn(f"Could not evaluate {expr!r}, treating as true.")
                keep = True

            if not keep:
                feature = m.group("feature")
                log.info(f"Dropping target-specific dependency on {feature!r}.")

        elif line == "optional = true\n" and feature:
            if not keep:
                # dropped feature was optional:
                # remove occurrences from feature dependencies
                dropped_optional_deps.add(feature)
            else:
                # optional dependency occurs in multiple targets:
                # do not drop from feature dependencies
                if feature in dropped_optional_deps:
                    dropped_optional_deps.remove(feature)

        elif line.startswith("["):
            # previous section ended, let's keep printing lines again
            keep = True

        if keep:
            good_lines += [line]
        else:
            dropped_lines += 1

    if not dropped_lines:
        # nothing to do, let's bail out
        return None

    good_lines2 = []
    in_features = False
    filt = filter_out_features_re(dropped_optional_deps)
    for line in good_lines:
        if line.rstrip() == "[features]":
            in_features = True
        elif line.startswith("["):
            in_features = False
        elif in_features:
            line = re.sub(filt, "", line)
            if not line:
                continue

        good_lines2 += [line]

    return good_lines2


def make_diff(path, lines1, mtime1, lines2, mtime2):
    return list(
        difflib.unified_diff(lines1, lines2, fromfile=path, tofile=path, fromfiledate=mtime1, tofiledate=mtime2)
    )


def make_patches(args, version, toml):
    """Returns up to two patches (automatic and manual).

    For the manual patch, an editor is spawned on toml and a diff is
    made after the editor returns.
    """
    mtime_before = file_mtime(toml)
    toml_before = open(toml).readlines()

    diff1 = diff2 = None
    toml_path = f"{args.crate}-{version}/Cargo.toml"

    # patching Cargo.toml involves multiple steps:
    #
    # 1) attempt to automatically drop "foreign" dependencies
    #    If this succeeded, remove the original Cargo.toml file, write the
    #    changed contents back to disk, and generate a diff.
    # 2) if requested, open Cargo.toml in an editor for further, manual changes
    #
    # The changes from *both* steps must be reflected in the Cargo.toml file
    # that ends up on disk after this function returns. Otherwise, the
    # calculated metadata and generated spec file will not reflect the patches
    # to Cargo.toml that were generated here.

    if toml_after := args.patch_foreign and drop_foreign_dependencies(toml_before):
        # remove original Cargo.toml file
        os.remove(toml)

        # write auto-patched Cargo.toml to disk
        with open(toml, "w") as file:
            file.writelines(toml_after)

        diff1 = make_diff(toml_path, toml_before, mtime_before, toml_after, mtime_before)
    else:
        toml_after = toml_before

    if args.patch:
        # open editor for Cargo.toml
        editor = util.detect_editor()
        subprocess.check_call([editor, toml])

        mtime_after2 = file_mtime(toml)
        toml_after2 = open(toml).readlines()

        diff2 = make_diff(toml_path, toml_after, mtime_before, toml_after2, mtime_after2)

    return diff1, diff2


def _is_path(path):
    return "/" in path or path in {".", ".."}


@sortify
def get_license_files(path):
    """Heuristic match on file names to detect license files"""
    exclude = {
        "vendor",
        "example",
        "examples",
        "_example",
        "_examples",
        "testdata",
        "_testdata",
        ".github",
        "tests",
        "test",
    }

    for root, dirs, files in os.walk(path, topdown=True):
        dirs[:] = [d for d in dirs if d not in exclude]
        for f in files:
            if LICENSES.match(f):
                yield os.path.relpath(os.path.join(root, f), path)


@sortify
def get_doc_files(path):
    """Heuristic match on file names to detect documentation files"""
    plus = re.compile(
        r"""
        .*\.(?:md|markdown|mdown|mkdn|rst|txt)|AUTHORS|
        AUTHORS[.-].*|CONTRIBUTORS|CONTRIBUTORS[.-].*|README|
        README[.-].*|CHANGELOG|CHANGELOG[.-].*|TODO|TODO[.-].*
        """,
        re.IGNORECASE | re.VERBOSE,
    )
    minus = re.compile(r"CMakeLists\.txt|.*\.tpl|.*\.in")

    for root, dirs, files in os.walk(path, topdown=True):
        dirs[:] = []
        for f in files:
            if plus.fullmatch(f) and not LICENSES.fullmatch(f) and not minus.fullmatch(f):
                yield os.path.relpath(os.path.join(root, f), path)


def get_package_info(package):
    """Download information about package from dist-git.

    Returns JSON with package metadata, or None if the package is
    unnkown or the spec file is not present.

    >>> rust2rpm.__main__.get_package_info('rust-alacritty')
    {...
    'name': 'rust-alacritty',
    'namespace': 'rpms',
    ...}
    """

    url = requests.compat.urljoin(DIST_GIT_URL, f"rpms/{package}")
    req = requests.get(url, headers={"User-Agent": "rust2rpm"})
    json = req.json()
    if "name" not in json:
        return None

    # E.g. https://src.fedoraproject.org/rpms/rust-tiny_http0.6/blob/rawhide/f/rust-tiny_http0.6.spec
    full_url = json["full_url"]
    spec_url = requests.compat.urljoin(full_url, f"blob/rawhide/f/rust-{package}.spec")
    req = requests.head(spec_url, headers={"User-Agent": "rust2rpm"})

    if not req.ok:
        # The repo exists, but doesn't have the spec file. We most
        # likely want to create a spec file to add to that repo.
        return None

    return json


def make_diff_metadata(args, crate, version):
    if _is_path(crate):
        # Only things that look like a paths are considered local arguments
        if crate.endswith(".crate"):
            cratef, crate, version = local_crate(crate, version)
        else:
            if args.store_crate:
                raise ValueError("--store-crate can only be used for a crate")

            toml, crate, version, doc_files, license_files = local_toml(crate, version)
            diffs = make_patches(args, version, toml)
            metadata = Metadata.from_file(toml)
            if len(metadata) > 1:
                log.warn(f"More than one set of metadata found for {toml}, using the first one.")
            metadata = metadata[0]
            return metadata.name, diffs, metadata, doc_files, license_files
    else:
        cratef, crate, version = download(crate, version)

    with files_from_crate(cratef, crate, version) as (toml, doc_files, license_files):
        if not license_files:
            log.error(f"No license files detected in {crate!r}.")

        diffs = make_patches(args, version, toml)
        metadata = Metadata.from_file(toml)
        if len(metadata) > 1:
            log.warn(f"More than one set of metadata found for {toml}, using the first one.")
        metadata = metadata[0]
    if args.store_crate:
        shutil.copy2(cratef, os.path.join(os.getcwd(), f"{metadata.name}-{version}.crate"))
    return crate, diffs, metadata, doc_files, license_files


def detect_rpmautospec(default_target, spec_file):
    """Guess whether %autorelease+%autochangelog should be used

    Returns False if we're not on Fedora or if the spec file exists and
    wasn't using rpmautospec already.
    """

    # We default to on only for selected distros for now…
    if default_target not in {"fedora"}:
        return False

    try:
        text = spec_file.read_text()
    except FileNotFoundError:
        # A new file, let's try the new thing.
        return True

    # We are redoing an existing spec file. Figure out if it had
    # %autochangelog enabled before.
    autochangelog_re = r"^\s*%(?:autochangelog|\{\??autochangelog\})\b"
    return any(re.match(autochangelog_re, line) for line in text.splitlines())


def guess_crate_name():
    """Guess crate name from directory name and/or spec file name

    If a spec file is present, we use the %crate variable. This is the best
    option. But if we're in a new directory, and don't have a spec file yet,
    let's assume that this is a dist-git directory and extract the crate name.
    For compat packages, the directory name will contain a version suffix,
    but a compat package would almost always be created from an existing
    dist-git directory, hence there'd be a spec file, so we can ignore this.
    """
    specs = glob.glob("*.spec")

    if len(specs) > 1:
        log.error(
            f"Found multiple spec files in the current working directory; "
            + "unable to determine crate name automatically."
        )
        return None

    if len(specs) == 1:
        crate = None
        spec = specs[0]

        for line in open(spec):
            if m := re.match(r"^%(?:global|define)\s+crate\s+(\S+)\s+", line):
                if crate:
                    log.error(
                        f"Found multiple definitions of the '%crate' macro in {spec!r}; "
                        + f"unable to determine crate name automatically."
                    )
                    return None
                crate = m.group(1)
                if "%" in crate:
                    log.error(f"The value of the %crate macro appears to contain other macros and cannot be parsed.")
                    return None
        if crate:
            log.success(f"Found valid spec file {spec!r} for the {crate!r} crate.")
        else:
            log.error(f"Invalid spec file {spec!r}; unable to determine crate name automatically.")
        return crate

    dirname = os.path.basename(os.getcwd())
    if m := re.match("^rust-([a-z+0-9_-]+)$", dirname):
        crate = m.group(1)
        log.info(f"Continuing with crate name {crate!r} based on the current working directory.")
        return crate

    return None


def get_parser():
    default_target = get_default_target()

    parser = argparse.ArgumentParser("rust2rpm", formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument(
        "--show-license-map",
        action="store_true",
        help="Print license mappings and exit",
    )
    parser.add_argument(
        "--translate-license",
        action="store_true",
        help="Print mapping for specified license and exit",
    )
    parser.add_argument(
        "--no-auto-changelog-entry",
        action="store_false",
        default=True,
        dest="auto_changelog_entry",
        help="Do not generate a changelog entry",
    )
    parser.add_argument(
        "--no-existence-check",
        action="store_false",
        default=True,
        dest="existence_check",
        help="Do not check whether the package already exists in dist-git",
    )
    parser.add_argument("-", "--stdout", action="store_true", help="Print spec and patches into stdout")
    parser.add_argument(
        "-t",
        "--target",
        action="store",
        choices=("plain", "fedora", "mageia", "opensuse"),
        default=default_target,
        help="Distribution target",
    )
    parser.add_argument(
        "--no-patch-foreign",
        action="store_false",
        default=True,
        dest="patch_foreign",
        help="Do not automatically drop foreign dependencies in Cargo.toml",
    )
    parser.add_argument(
        "-p",
        "--patch",
        action="store_true",
        help="Do manual patching of Cargo.toml",
    )
    parser.add_argument(
        "-s",
        "--store-crate",
        action="store_true",
        help="Store crate in current directory",
    )
    parser.add_argument(
        "-a",
        "--rpmautospec",
        action="store_true",
        default=None,
        help="Use autorelease and autochangelog features",
    )
    parser.add_argument(
        "--no-rpmautospec",
        action="store_false",
        dest="rpmautospec",
        help="Do not use rpmautospec",
    )
    parser.add_argument(
        "--relative-license-paths",
        action="store_true",
        help="Put all license files in main license directory",
    )
    parser.add_argument(
        "--all-features",
        action="store_true",
        help="Activate all available features",
    )
    parser.add_argument(
        "--dynamic-buildrequires",
        action="store_true",
        default=None,
        help="Use dynamic BuildRequires feature",
    )
    parser.add_argument(
        "--no-dynamic-buildrequires",
        action="store_false",
        dest="dynamic_buildrequires",
        help="Do not use dynamic BuildRequires feature",
    )
    parser.add_argument(
        "--suffix",
        action="store",
        help="Package suffix",
    )
    parser.add_argument(
        "crate",
        help="crates.io name\n" "path/to/local.crate\n" "path/to/project/",
        nargs="?",
    )
    parser.add_argument(
        "version",
        nargs="?",
        help="crates.io version",
    )

    return parser


@util.exit_on_common_errors()
def main():
    parser = get_parser()
    args = parser.parse_args()

    if args.show_license_map:
        licensing.dump_sdpx_to_fedora_map(sys.stdout)
        return

    if args.translate_license:
        license, comments = licensing.translate_license(args.target, args.crate)
        if comments:
            for comment in comments.split("\n"):
                log.info(comment)
        print(license)
        return

    if args.crate is None:
        args.crate = guess_crate_name()
        if args.crate is None:
            parser.error("crate/path argument missing and autodetection failed")

    try:
        crate, diffs, metadata, doc_files, license_files = make_diff_metadata(args, args.crate, args.version)
    except NoVersionsError:
        log.error(f"No versions are available for crate {args.crate!r}.")
        sys.exit(1)

    pkg_name = package_name_suffixed(metadata.name, args.suffix)

    patch_files = (
        f"{metadata.name}-fix-metadata-auto.diff" if diffs[0] else None,
        f"{metadata.name}-fix-metadata.diff" if diffs[1] else None,
    )

    spec_file = pathlib.Path(f"{pkg_name}.spec")

    if args.target in {"fedora"} and args.existence_check and not os.path.exists(spec_file):
        # No specfile, so this is probably a new package
        if package_info := get_package_info(pkg_name):
            if args.suffix:
                log.warn(
                    f"Version {args.suffix}.* of the crate {metadata.name!r} is already "
                    + f"packaged for Fedora: {package_info['full_url']}"
                )
            else:
                log.warn(f"Crate {metadata.name!r} is already packaged for Fedora: {package_info['full_url']}")

            log.info("Re-run with --no-existence-check to create a new spec file from scratch.")
            sys.exit(1)

    if args.rpmautospec is None:
        args.rpmautospec = detect_rpmautospec(args.target, spec_file)

    if args.dynamic_buildrequires is None:
        args.dynamic_buildrequires = args.target == "fedora"

    packager = util.detect_packager()

    conf = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
    confs = conf.read([".rust2rpm.conf", "_rust2rpm.conf", "rust2rpm.conf"])

    # clean up configuration files with deprecated names
    if len(confs) > 1:
        log.error(
            "More than one *rust2rpm.conf file is present in this directory. "
            + "Ensure that there is only one, and that it has the correct contents."
        )
        sys.exit(1)

    if ".rust2rpm.conf" in confs and "rust2rpm.conf" not in confs:
        os.rename(".rust2rpm.conf", "rust2rpm.conf")
        log.info("Renamed deprecated, hidden .rust2rpm.conf file to rust2rpm.conf.")

    if "_rust2rpm.conf" in confs and "rust2rpm.conf" not in confs:
        os.rename("_rust2rpm.conf", "rust2rpm.conf")
        log.info("Renamed deprecated _rust2rpm.conf file to rust2rpm.conf.")

    if args.target not in conf:
        conf.add_section(args.target)

    conf_all_features = conf[args.target].getboolean("all-features")
    if conf_all_features is False and args.all_features:
        log.warn(
            'Conflicting settings for enabling all features: The setting is "false"'
            + 'in rust2rpm.conf but it was enabled with the "--all-features" CLI flag.'
        )

    spec_contents = generator.spec_file_render(
        args=args,
        pkg_name=pkg_name,
        crate=crate,
        metadata=metadata,
        patch_file_automatic=patch_files[0],
        patch_file_manual=patch_files[1],
        packager=packager,
        doc_files=doc_files,
        license_files=license_files,
        distconf=conf[args.target],
        all_features=conf_all_features or args.all_features,
    )

    if args.stdout:
        print(f"# {spec_file}")
        print(spec_contents)
        for fname, diff in zip(patch_files, diffs):
            if fname:
                print(f"# {fname}")
                print("".join(diff), end="")
    else:
        with open(spec_file, "w") as fobj:
            fobj.write(spec_contents)
        log.success(f"Generated: {fobj.name}")
        for fname, diff in zip(patch_files, diffs):
            if fname:
                with open(fname, "w") as fobj:
                    fobj.writelines(diff)
                log.success(f"Generated: {fobj.name}")


if __name__ == "__main__":
    main()
