import ast
import functools

import pyparsing as pp
from pyparsing import ParseException

from . import log
from . import TARGET_ARCHES

pp.ParserElement.enablePackrat()

# ConfigurationPredicate :
#      ConfigurationOption
#    | ConfigurationAll
#    | ConfigurationAny
#    | ConfigurationNot
# ConfigurationOption :
#    IDENTIFIER (= (STRING_LITERAL | RAW_STRING_LITERAL))?
# ConfigurationAll
#    all ( ConfigurationPredicateList? )
# ConfigurationAny
#    any ( ConfigurationPredicateList? )
# ConfigurationNot
#    not ( ConfigurationPredicate )
# ConfigurationPredicateList
#    ConfigurationPredicate (, ConfigurationPredicate)* ,?

# cfg(target_os = "macos")
# cfg(any(foo, bar))
# cfg(all(unix, target_pointer_width = "32"))
# cfg(not(foo))

IDENT_CHARS = pp.alphas + "_", pp.alphanums + "_"


def _call(word, arg):
    return pp.Group(pp.Literal(word) + pp.Suppress("(") + arg + pp.Suppress(")"))


@functools.cache
def cfg_grammar():
    pred = pp.Forward()

    ident = pp.Word(IDENT_CHARS[0], IDENT_CHARS[1])
    option = pp.Group(ident + pp.Optional(pp.Suppress("=") + pp.quotedString))

    not_ = _call("not", pred)

    # pp.pyparsing_common.comma_separated_list?
    # any_ = _call('any', pp.pyparsing_common.comma_separated_list(pred))
    # all_ = _call('all', pp.pyparsing_common.comma_separated_list(pred))
    # all_ = _call('all', pp.delimited_list(pred))

    any_ = _call("any", pred + pp.ZeroOrMore(pp.Suppress(",") + pred))
    all_ = _call("all", pred + pp.ZeroOrMore(pp.Suppress(",") + pred))

    pred <<= not_ | any_ | all_ | option

    grammar = _call("cfg", pred)
    return grammar


@functools.cache
def evaluate_predicate(name: str, value: str, target_arch: str) -> bool:
    # based on: https://doc.rust-lang.org/reference/conditional-compilation.html

    match name:
        case "target_arch":
            # Needs to be ignored, as we cannot generate patches that are
            # different depending on the host architecture - except if the
            # target architecture is "wasm32", which we don't support.
            return value == target_arch

        case "target_feature":
            # The "target_feature" predicate can be ignored as well, since the
            # valid values for this predicate are architecture-dependent.
            return True

        case "target_os":
            return value == "linux"

        case "target_family":
            return value == "unix"

        case "target_env":
            # The "target_env" predicate is used to disambiguate target
            # platforms based on its C library / C ABI (i.e. we can ignore
            # "msvc" and "musl"), and if there's no need to disambiguate, the
            # value can be the empty string.
            return value in ["", "gnu"]

        case "target_endian":
            # Needs to be ignored, as we cannot generate patches that are
            # different depending on the host architecture.
            return True

        case "target_pointer_width":
            # Needs to be ignored, as we cannot generate patches that are
            # different depending on the host architecture.
            return True

        case "target_vendor":
            # On linux systems, "target_vendor" is always "unknown".
            return value == "unknown"

        case _:
            log.warn(f'Ignoring invalid predicate \'"{name}" = "{value}"\' in cfg-expression.')
            return False


@functools.cache
def evaluate_atom(name: str) -> bool:
    match name:
        case "unix":
            return True
        case "windows":
            return False
        case "miri":
            return False
        case _:
            log.warn(
                f"Ignoring unknown identifier {name!r} in cfg-expression. "
                + 'only "unix", "windows", and "miri" are standard identifiers; '
                + 'any non-standard "--cfg" flags are ignored.'
            )
            return False


def evaluate(expr, target_arch: str, nested: bool = False) -> bool:
    if hasattr(expr, "asList"):
        expr = expr.asList()  # compat with pyparsing 2.7.x
    match expr:
        case ["cfg", subexpr] if not nested:
            return evaluate(subexpr, target_arch, True)
        case ["not", subexpr] if nested:
            return not evaluate(subexpr, target_arch, True)
        case ["all", *args] if nested:
            return all(evaluate(arg, target_arch, True) for arg in args)
        case ["any", *args] if nested:
            return any(evaluate(arg, target_arch, True) for arg in args)
        case [variable, value] if nested:
            v = ast.literal_eval(value)
            return evaluate_predicate(variable, v, target_arch)
        case [variable] if nested:
            return evaluate_atom(variable)
        case _:
            raise ValueError


def parse_and_evaluate(expr):
    parsed = cfg_grammar().parseString(expr)[0]

    # evaluate cfg-expression for all supported target_arch values
    # returns True if it evaluates to True for any supported architecture
    return any(evaluate(parsed, target_arch) for target_arch in TARGET_ARCHES)
