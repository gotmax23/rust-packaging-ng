import argparse
import glob
import os
import shlex
import subprocess
import sys

from rust2rpm.core.metadata import Metadata, Dependency


def _get_binaries(cargo_toml):
    manifest = Metadata.manifest(cargo_toml, check=False)
    return [t["name"] for t in manifest.get("targets", []) if "bin" in t["kind"]]


def _cargo_toml(source_path, path, exclude_vendor=True):
    """Find a Cargo.toml related with a binary."""
    # Finding the Cargo.toml is a bit tricky, and the general idea is
    # like this:
    #
    #   - `source_path`: is set but the dependecy generator call
    #     (cargo_bundled.attr) to point to `%{_builddir}`, so where
    #     the sources are (`.../rpmbuild/BUILD`)
    #
    #   - `path`: can point to an executable when called by
    #     cargo_bundler.attr, that lives in `%{_buildroot}`, for
    #     example `.../rpmbuild/BUILDROOT/<PKGNAME>/usr/bin/<BINNAME>`
    #
    #   - `path`: can also point to a Cargo.toml when called from
    #     command line
    #
    #   - If `path` is a binary, we search the Cargo.toml from
    #     `source_path` that generates this specific binary

    # If path is already a Cargo.toml file, we are done
    binary_or_cargo_toml = os.path.basename(path)
    if binary_or_cargo_toml == "Cargo.toml":
        return os.path.join(source_path, path)

    cargo_tomls = glob.glob(os.path.join(source_path, "**/Cargo.toml"), recursive=True)
    for cargo_toml in cargo_tomls:
        if exclude_vendor and "vendor" in cargo_toml.split(os.sep):
            continue
        if binary_or_cargo_toml in _get_binaries(cargo_toml):
            return cargo_toml

    raise FileNotFoundError(f"Cargo.toml not found for binary {binary_or_cargo_toml}")


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-n", "--name", action="store_true", help="Print name")
    group.add_argument("-v", "--version", action="store_true", help="Print version")
    group.add_argument("-rv", "--rpm-version", action="store_true", help="Print version (in RPM format)")
    group.add_argument("-t", "--target-kinds", action="store_true", help="Print target kinds")
    group.add_argument("-l", "--list-features", action="store_true", help="Print features")
    group.add_argument("-P", "--provides", action="store_true", help="Print Provides")
    group.add_argument("-R", "--requires", action="store_true", help="Print Requires")
    group.add_argument("-BR", "--build-requires", action="store_true", help="Print BuildRequires")
    group.add_argument("-TR", "--test-requires", action="store_true", help="Print TestRequires")
    group.add_argument("-PV", "--provides-vendor", action="store_true", help="Print Provides when vendoring")
    fgroup = parser.add_mutually_exclusive_group()
    fgroup.add_argument("-a", "--all-features", action="store_true", help="Activate all features")
    fgroup.add_argument("-f", "--features", default="default", help="Feature(s) to work on (comma-separated)")
    parser.add_argument("--vendor", action="store_true", help="Print vendoring provides (even when not vendored)")
    parser.add_argument("--include-workspaces", action="store_true", help="Include workspaces in the analysis")
    parser.add_argument("-p", "--path", help="Path to the source project")
    parser.add_argument("file", nargs="*", help="Path(s) to Cargo.toml")
    args = parser.parse_args()

    args.path = os.path.abspath(args.path) if args.path else os.getcwd()

    files = args.file or [f.rstrip() for f in sys.stdin.readlines()]
    files = [_cargo_toml(args.path, f) for f in files]

    features = set()
    for f in args.features.split(","):
        features.add(f or None)

    def process_metadata(md):
        data = []
        if args.name:
            data.append(md.name)
        if args.version:
            data.append(md._version)
        if args.rpm_version:
            data.append(md.version)
        if args.target_kinds:
            data.extend(tgt.kind for tgt in md.targets)
        if args.list_features:
            data.extend(f for f in md.dependencies if f is not None)
        if args.provides:
            data.extend(md.provides(f) for f in features)
        if args.requires:
            # Someone should own /usr/share/cargo/registry
            data.append("cargo")
            if args.all_features:
                data.extend(md.all_dependencies)
            else:
                for f in features:
                    data.extend(md.requires(f))
        if args.build_requires:
            data.append("rust-packaging")
            if args.all_features:
                data.extend(md.all_dependencies)
            else:
                for f in features:
                    data.extend(md.requires(f, resolve=True))
        if args.test_requires:
            data.extend(md.dev_dependencies)
        if args.provides_vendor:
            # Print the vendoring providers only if the 'vendor'
            # directory is present
            if args.vendor or os.path.isdir("vendor"):
                data.extend(md.resolved_dependencies())
        return data

    for f in files:
        data = set()
        mds = Metadata.from_file(f, include_members=args.include_workspaces)
        for md in mds:
            # process_metadata can return an [string], but can be also
            # a [Dependency] instance, that once presented have
            # multiple substrings.  If we want to order the data and
            # remove all the duplicates we should first normalize it
            metadata_lines = []
            for some in process_metadata(md):
                if isinstance(some, Dependency):
                    metadata_lines.extend(some.normalize())
                else:
                    metadata_lines.append(some)
            data.update(metadata_lines)
        for line in sorted(data):
            print(line)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        cmd = shlex.join(e.cmd)
        sys.exit(f"Subcommand failed with code {e.returncode}: {cmd}")
