import os
import csv
import functools

from . import log

SPDX_TO_FEDORA_CSV = os.path.dirname(__file__) + "/spdx_to_fedora.csv"


def translate_slashes(license):
    "Replace all slashes with OR, emit warning"
    split = [l.strip() for l in license.split("/")]
    if len(split) > 1:
        log.info('Upstream uses deprecated "/" syntax. Replacing with "OR"')
    return " OR ".join(split)


@functools.lru_cache()
def spdx_to_fedora_map():
    with open(SPDX_TO_FEDORA_CSV, newline="") as f:
        reader = csv.DictReader(f)
        return {
            line["SPDX License Identifier"]: line["Fedora Short Name"]
            for line in reader
            if line["SPDX License Identifier"]
        }


def dump_sdpx_to_fedora_map(file):
    for k, v in spdx_to_fedora_map().items():
        print(f"{k} → {v}", file=file)


def translate_license_fedora(license):
    comments = []
    final = []
    for tag in license.split():
        # We accept all variant cases, but output lowercase which is what Fedora LicensingGuidelines specify
        if tag.upper() == "OR":
            final.append("or")
        elif tag.upper() == "AND":
            final.append("and")
        else:
            if tag.endswith("+"):
                key = tag[:-1] + "-or-later"
                fulltag = f"{tag} ({key})"
            else:
                key = fulltag = tag

            mapped = spdx_to_fedora_map().get(key, None)
            if mapped is None:
                comments += [f"# FIXME: Upstream uses unknown SPDX tag {fulltag}!"]
                final.append(tag)
            elif mapped == "":
                comments += [
                    f"# FIXME: Upstream SPDX tag {fulltag} not listed in Fedora's good licenses list.",
                    "# FIXME: This package might not be allowed in Fedora!",
                ]
                final.append(tag)
            else:
                final.append(mapped)
                if mapped != tag:
                    log.info(f"Upstream license tag {fulltag!r} translated to {mapped!r}.")
    return (" ".join(final), "\n".join(comments) or None)


def translate_license(target, license):
    license = translate_slashes(license)
    if target in {"mageia"}:
        return translate_license_fedora(license)
    return license, None
