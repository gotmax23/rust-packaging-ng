from . import licensing

__version__ = "23"

TARGET_ARCHES = [
    "x86_64",
    "x86",
    "aarch64",
    "arm",
    "powerpc64",
    "s390x",
]
