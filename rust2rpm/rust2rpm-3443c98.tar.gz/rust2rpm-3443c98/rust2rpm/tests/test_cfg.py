import pytest

from rust2rpm import cfg


def test_pyparsing_run_tests():
    g = cfg.cfg_grammar()

    g.runTests(
        """\
        cfg(target_os = "macos")
        cfg(any(foo, bar))
        cfg(all(unix, target_pointer_width = "32"))
        cfg(not(foo))
        """
    )


@pytest.mark.parametrize(
    "expr, expected",
    [
        ('cfg(target_os = "macos")', False),
        ("cfg(any(foo, bar))", False),
        ('cfg(all(unix, target_pointer_width = "16"))', True),
        ("cfg(not(foo))", True),
        ("cfg(unix)", True),
        ("cfg(not(unix))", False),
        ("cfg(windows)", False),
        ("cfg(miri)", False),
        ("cfg(linux)", False),  # not defined
        ("cfg(not(windows))", True),
        ("cfg(any(unix, windows))", True),
        ("cfg(any(windows, unix))", True),
        ("cfg(any(windows, windows, windows))", False),
        ('cfg(target_os = "linux")', True),
        ('cfg(any(target_os = "linux"))', True),
        ('cfg(all(target_os = "linux"))', True),
        ('cfg(any(target_os = "linux", target_os = "macos"))', True),
        ('cfg(any(target_pointer_width = "16", target_pointer_width = "32", target_pointer_width = "64"))', True),
        # from rustix 0.35.12
        ('cfg(any(target_os = "android", target_os = "linux"))', True),
        (
            'cfg(all(not(rustix_use_libc), not(miri), target_os = "linux", '
            'any(target_arch = "x86", all(target_arch = "x86_64", target_pointer_width = "64"), '
            'all(target_endian = "little", any(target_arch = "arm", '
            'all(target_arch = "aarch64", target_pointer_width = "64"), '
            'target_arch = "powerpc64", target_arch = "riscv64", target_arch = "mips", target_arch = "mips64")))))',
            True,
        ),
        (
            'cfg(any(rustix_use_libc, miri, not(all(target_os = "linux", '
            'any(target_arch = "x86", all(target_arch = "x86_64", target_pointer_width = "64"), '
            'all(target_endian = "little", any(target_arch = "arm", '
            'all(target_arch = "aarch64", target_pointer_width = "64"), '
            'target_arch = "powerpc64", target_arch = "riscv64", target_arch = "mips", target_arch = "mips64")))))))',
            True,
        ),
        ('cfg(not(target_os = "emscripten"))', True),
        # from tokio 1.21.2
        ('cfg(all(any(target_arch = "wasm32", target_arch = "wasm64"), not(target_os = "wasi")))', False),
        ("cfg(loom)", False),
        ('cfg(not(all(any(target_arch = "wasm32", target_arch = "wasm64"), target_os = "unknown")))', True),
        ('cfg(not(any(target_arch = "wasm32", target_arch = "wasm64")))', True),
        ('cfg(target_os = "freebsd")', False),
        ("cfg(tokio_unstable)", False),
    ],
)
def test_expressions(expr, expected):
    value = cfg.parse_and_evaluate(expr)
    assert value == expected
