import operator
import time

import jinja2

from . import __version__, licensing
from .core import metadata


def to_list(s):
    if not s:
        return []
    return list(filter(None, (l.strip() for l in s.splitlines())))


def spec_file_template():
    env = jinja2.Environment(
        loader=jinja2.ChoiceLoader(
            [
                jinja2.FileSystemLoader(["/"]),
                jinja2.PackageLoader("rust2rpm", "templates"),
            ]
        ),
        extensions=["jinja2.ext.do"],
        trim_blocks=True,
        lstrip_blocks=True,
    )

    env.globals["normalize_deps"] = metadata.normalize_deps
    env.globals["to_list"] = to_list

    return env.get_template("main.spec")


def spec_file_render(
    args,
    pkg_name,
    crate,
    metadata,
    patch_file_manual,
    patch_file_automatic,
    packager,
    doc_files,
    license_files,
    distconf,
    all_features,
    date=None,
):
    template = spec_file_template()

    bins = [tgt for tgt in metadata.targets if tgt.kind == "bin"]
    libs = [tgt for tgt in metadata.targets if tgt.kind in {"lib", "rlib", "proc-macro"}]
    is_bin = len(bins) > 0
    is_lib = len(libs) > 0

    # sort binaries by name for consistent ordering
    bins.sort(key=operator.attrgetter("name"))

    kwargs = {
        "generator_version": __version__,
        "target": args.target,
        "crate": crate,
        "include_devel": is_lib,
        "pkg_name": pkg_name,
        "auto_changelog_entry": args.auto_changelog_entry,
        "rpmautospec": args.rpmautospec,
        "relative_license_paths": args.relative_license_paths,
        "generate_buildrequires": args.dynamic_buildrequires,
        "doc_files": doc_files,
        "license_files": license_files,
        "distconf": distconf,
        "all_features": all_features,
    }

    if is_bin:
        kwargs["include_main"] = True
        kwargs["bins"] = bins
    elif is_lib:
        kwargs["include_main"] = False
    else:
        raise ValueError("No bins and no libs")

    if args.target in {"fedora", "mageia", "opensuse"}:
        kwargs["include_build_requires"] = True
        kwargs["include_provides"] = False
        kwargs["include_requires"] = False
    elif args.target == "plain":
        kwargs["include_build_requires"] = True
        kwargs["include_provides"] = True
        kwargs["include_requires"] = True
    else:
        assert False, f"Unknown target {args.target!r}"

    if args.target == "mageia":
        kwargs["pkg_release"] = "%mkrel 1"
        kwargs["rust_group"] = "Development/Rust"
    elif args.target == "opensuse":
        kwargs["spec_copyright_year"] = time.strftime("%Y")
        kwargs["pkg_release"] = "0"
        kwargs["rust_group"] = "Development/Libraries/Rust"
    elif args.rpmautospec:
        kwargs["pkg_release"] = "%autorelease"
    else:
        kwargs["pkg_release"] = "1%{?dist}"

    time_args = ["%a %b %d %T %Z %Y" if args.target in {"opensuse"} else "%a %b %d %Y"] + ([date] if date else [])
    kwargs["date"] = time.strftime(*time_args)

    if packager is not None:
        kwargs["packager"] = packager

    if metadata.license is not None:
        license, comments = licensing.translate_license(args.target, metadata.license)
        kwargs["license"] = license
        kwargs["license_comments"] = comments

    spec_contents = template.render(
        metadata=metadata,
        patch_file_manual=patch_file_manual,
        patch_file_automatic=patch_file_automatic,
        **kwargs,
    )

    if not spec_contents.endswith("\n"):
        spec_contents += "\n"

    return spec_contents
