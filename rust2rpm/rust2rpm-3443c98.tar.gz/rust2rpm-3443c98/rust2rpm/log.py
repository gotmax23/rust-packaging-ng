"""
Simple logging implementation that wraps long messages to 80 characters,
indents multi-line messages, and uses colors for errors (red), warnings
(yellow), and success (green), and prints output to STDERR only.
"""

import sys
import textwrap

from termcolor import colored


def _eprint(message):
    print(message, file=sys.stderr)


def _wrap(message, prefix):
    return textwrap.wrap(message, 80, initial_indent=f"{prefix} ", subsequent_indent=" " * (len(prefix) + 1))


def success(message):
    _eprint(colored("\n".join(_wrap(message, "•")), "green"))


def info(message):
    _eprint(colored("\n".join(_wrap(message, "•")), "grey"))


def warn(message):
    _eprint(colored("\n".join(_wrap(message, "WARNING:")), "yellow"))


def error(message):
    _eprint(colored("\n".join(_wrap(message, "ERROR:")), "red", attrs=["dark"]))
