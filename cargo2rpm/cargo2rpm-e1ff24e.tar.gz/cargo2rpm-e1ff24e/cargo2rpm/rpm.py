from typing import Dict, Optional, Set

from cargo2rpm import CARGO_BUGGY_RESOLVER
from cargo2rpm.metadata import Package, FeatureFlags, Metadata
from cargo2rpm.semver import Version


def buildrequires(package: Package, flags: FeatureFlags, with_dev_deps: bool) -> Set[str]:
    enabled, optional_enabled, other_enabled, other_conditional = package.get_enabled_features_transitive(flags)

    normal = package.get_normal_dependencies(False)
    normal_optional = package.get_normal_dependencies(True)
    build = package.get_build_dependencies(False)
    build_optional = package.get_build_dependencies(True)
    dev = package.get_dev_dependencies()

    # keep track of dependencies and which features are enabled for them:
    # - determine union of enabled features for all dependencies
    deps_enabled_features: Dict[str, Set[str]] = dict()
    # - determine whether default features are enabled for all dependencies
    deps_default_features: Dict[str, bool] = dict()

    # unconditionally enabled features of normal dependencies
    for (name, dep) in normal.items():
        features = deps_enabled_features.get(name) or set()
        features.update(dep.features)
        deps_enabled_features[name] = features

        defaults = deps_default_features.get(name) or False
        defaults = defaults or dep.uses_default_features
        deps_default_features[name] = defaults

    # unconditionally enabled features of enabled, optional, normal dependencies
    for (name, dep) in normal_optional.items():
        if name in optional_enabled:
            features = deps_enabled_features.get(name) or set()
            features.update(dep.features)
            deps_enabled_features[name] = features

            defaults = deps_default_features.get(name) or False
            defaults = defaults or dep.uses_default_features
            deps_default_features[name] = defaults

    # unconditionally enabled features of build-dependencies
    for (name, dep) in build.items():
        features = deps_enabled_features.get(name) or set()
        features.update(dep.features)
        deps_enabled_features[name] = features

        defaults = deps_default_features.get(name) or False
        defaults = defaults or dep.uses_default_features
        deps_default_features[name] = defaults

    # unconditionally enabled features of enabled, optional, build-dependencies
    for (name, dep) in build_optional.items():
        if name in optional_enabled:
            features = deps_enabled_features.get(name) or set()
            features.update(dep.features)
            deps_enabled_features[name] = features

            defaults = deps_default_features.get(name) or False
            defaults = defaults or dep.uses_default_features
            deps_default_features[name] = defaults

    # unconditionally enabled features of enabled dev-dependencies
    if with_dev_deps:
        for (name, dep) in dev.items():
            features = deps_enabled_features.get(name) or set()
            features.update(dep.features)
            deps_enabled_features[name] = features

            defaults = deps_default_features.get(name) or False
            defaults = defaults or dep.uses_default_features
            deps_default_features[name] = defaults

    # features unconditionally enabled by feature dependencies
    for (name, other_features) in other_enabled.items():
        features = deps_enabled_features.get(name) or set()
        features.update(other_features)
        deps_enabled_features[name] = features

    # features conditionally enabled by feature dependencies
    for (name, other_features) in other_conditional.items():
        if name in enabled or CARGO_BUGGY_RESOLVER:
            features = deps_enabled_features.get(name) or set()
            features.update(other_features)
            deps_enabled_features[name] = features

    # collect dependencies taking into account which features are enabled
    brs = set()

    # normal dependencies
    for (name, dep) in normal.items():
        if dep.path:
            continue

        if deps_default_features[name]:
            brs.add(dep.to_rpm("default"))
        else:
            brs.add(dep.to_rpm(None))
        for feature in deps_enabled_features[name]:
            brs.add(dep.to_rpm(feature))

    # optional normal dependencies
    for (name, dep) in normal_optional.items():
        if dep.path:
            continue

        if name in optional_enabled:
            if deps_default_features[name]:
                brs.add(dep.to_rpm("default"))
            else:
                brs.add(dep.to_rpm(None))
            for feature in deps_enabled_features[name]:
                brs.add(dep.to_rpm(feature))

    # build-dependencies
    for (name, dep) in build.items():
        if dep.path:
            continue

        if deps_default_features[name]:
            brs.add(dep.to_rpm("default"))
        else:
            brs.add(dep.to_rpm(None))
        for feature in deps_enabled_features[name]:
            brs.add(dep.to_rpm(feature))

    # optional build-dependencies
    for (name, dep) in build_optional.items():
        if dep.path:
            continue

        if name in optional_enabled:
            if deps_default_features[name]:
                brs.add(dep.to_rpm("default"))
            else:
                brs.add(dep.to_rpm(None))
            for feature in deps_enabled_features[name]:
                brs.add(dep.to_rpm(feature))

    # dev-dependencies
    if with_dev_deps:
        for (name, dep) in dev.items():
            if dep.path:
                continue

            if deps_default_features[name]:
                brs.add(dep.to_rpm("default"))
            else:
                brs.add(dep.to_rpm(None))
            for feature in deps_enabled_features[name]:
                brs.add(dep.to_rpm(feature))

    return brs


def workspace_buildrequires(metadata: Metadata, flags: FeatureFlags, with_dev_deps: bool) -> Set[str]:
    all_brs = set()

    member_flags = metadata.get_feature_flags_for_workspace_members(flags)
    for package in metadata.packages:
        all_brs.update(buildrequires(package, member_flags[package.name], with_dev_deps))

    return all_brs


def devel_subpackage_names(package: Package) -> Set[str]:
    # no feature subpackages are generated for binary-only crates
    if not package.is_lib():
        return set()

    names = package.get_feature_names()

    # the "default" feature is always implicitly defined
    if "default" not in names:
        names.add("default")

    return names


def _requires_crate(package) -> Set[str]:
    normal = package.get_normal_dependencies(False)
    build = package.get_build_dependencies(False)

    deps = set()

    # dependency on cargo is mandatory
    deps.add("cargo")

    # normal dependencies
    for dep in normal.values():
        if dep.uses_default_features:
            deps.add(dep.to_rpm("default"))
        else:
            deps.add(dep.to_rpm(None))
        for depf in dep.features:
            deps.add(dep.to_rpm(depf))

    # build-dependencies
    for dep in build.values():
        if dep.uses_default_features:
            deps.add(dep.to_rpm("default"))
        else:
            deps.add(dep.to_rpm(None))
        for depf in dep.features:
            deps.add(dep.to_rpm(depf))

    return deps


def _requires_feature(package: Package, feature: str) -> Set[str]:
    deps = set()

    # dependency on cargo is mandatory
    deps.add("cargo")

    if feature == "default" and "default" not in package.features.keys():
        # default feature is implicitly defined but empty
        deps.add(package.to_rpm_dependency(None))
        return deps

    feature_deps = package.features[feature]

    normal = package.get_normal_dependencies(False)
    normal_optional = package.get_normal_dependencies(True)
    build_optional = package.get_build_dependencies(True)

    # always add a dependency on the main crate
    deps.add(package.to_rpm_dependency(None))

    for fdep in feature_deps:
        if fdep.startswith("dep:"):
            # optional dependency
            name = fdep.removeprefix("dep:")

            found = False
            if dep := normal_optional.get(name):
                # optional normal dependency
                found = True
                if dep.uses_default_features:
                    deps.add(dep.to_rpm("default"))
                else:
                    deps.add(dep.to_rpm(None))
                for depf in dep.features:
                    deps.add(dep.to_rpm(depf))

            if dep := build_optional.get(name):
                # optional build-dependency
                found = True
                if dep.uses_default_features:
                    deps.add(dep.to_rpm("default"))
                else:
                    deps.add(dep.to_rpm(None))
                for depf in dep.features:
                    deps.add(dep.to_rpm(depf))

            if not found:  # pragma nocover
                raise ValueError(f"No optional dependency found with name {name!r}.")

        elif "/" in fdep and "?/" not in fdep:
            # dependency with specified feature
            name, feat = fdep.split("/")

            # implicitly enabled optional dependency
            if dep := normal_optional.get(name):
                deps.add(dep.to_rpm(feat))
            if dep := build_optional.get(name):
                deps.add(dep.to_rpm(feat))

            # normal dependency
            if dep := normal.get(name):
                deps.add(dep.to_rpm(feat))

        elif "?/" in fdep:
            # conditionally enabled dependency feature
            name, feat = fdep.split("?/")

            if dep := normal_optional.get(name):
                if CARGO_BUGGY_RESOLVER:
                    deps.add(f"{dep.to_rpm(feat)}")
                else:
                    deps.add(f"({dep.to_rpm(feat)} if {dep.to_rpm(None)})")
            if dep := build_optional.get(name):
                if CARGO_BUGGY_RESOLVER:
                    deps.add(f"{dep.to_rpm(feat)}")
                else:
                    deps.add(f"({dep.to_rpm(feat)} if {dep.to_rpm(None)})")

        else:
            # dependency on a feature of the current crate
            if fdep not in package.features.keys():  # pragma nocover
                raise ValueError(f"Invalid feature dependency (not a feature name): {fdep!r}")

            deps.add(package.to_rpm_dependency(fdep))

    return deps


def requires(package: Package, feature: Optional[str]) -> Set[str]:  # pragma nocover
    if feature is None:
        return _requires_crate(package)
    else:
        return _requires_feature(package, feature)


def _provides_crate(package: Package) -> str:
    rpm_version = Version.parse(package.version).to_rpm()
    return f"crate({package.name}) = {rpm_version}"


def _provides_feature(package: Package, feature: str) -> str:
    rpm_version = Version.parse(package.version).to_rpm()
    return f"crate({package.name}/{feature}) = {rpm_version}"


def provides(package: Package, feature: Optional[str]) -> str:  # pragma nocover
    if feature is None:
        return _provides_crate(package)
    else:
        return _provides_feature(package, feature)
