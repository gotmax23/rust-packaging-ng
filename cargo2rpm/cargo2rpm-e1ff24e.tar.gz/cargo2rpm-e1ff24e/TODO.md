# TODO

- `%{nil}`

# WISHLIST

- enable `required-features` of `test/bin` targets automatically during
  resolution of BuildRequires if  `with_check` is enabled
- for crates that ship binaries, enable `required-features` of `bin`
  targets automatically
- for crates that ship libraries, enable `required-features` of `cdylib`
  targets automatically
- support for automatically generating Requires / BuildRequires based
  on `system-deps` metadata
