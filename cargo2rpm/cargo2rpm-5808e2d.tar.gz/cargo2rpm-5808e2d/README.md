# cargo2rpm

Work-in-progress translation layer between cargo and RPM.
Intended to replace parts of the aging code base of [rust2rpm].

[rust2rpm]: https://pagure.io/fedora-rust/rust2rpm
