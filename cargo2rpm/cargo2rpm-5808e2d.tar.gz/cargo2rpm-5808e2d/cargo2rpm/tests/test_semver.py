from typing import List, Optional

from cargo2rpm.semver import VERSION_REGEX, VERSION_REQ_REGEX, Comparator, Op, Version, VersionReq
from cargo2rpm.utils import short_repr

import pytest


@pytest.mark.parametrize(
    "string,expected",
    [
        ("1.0.0-alpha", dict(major="1", minor="0", patch="0", pre="alpha", build=None)),
        ("1.0.0-alpha.1", dict(major="1", minor="0", patch="0", pre="alpha.1", build=None)),
        ("1.0.0-0.3.7", dict(major="1", minor="0", patch="0", pre="0.3.7", build=None)),
        ("1.0.0-x.7.z.92", dict(major="1", minor="0", patch="0", pre="x.7.z.92", build=None)),
        ("1.0.0-x-y-z.--", dict(major="1", minor="0", patch="0", pre="x-y-z.--", build=None)),
        ("1.0.0-alpha+001", dict(major="1", minor="0", patch="0", pre="alpha", build="001")),
        ("1.0.0+20130313144700", dict(major="1", minor="0", patch="0", pre=None, build="20130313144700")),
        ("1.0.0-beta+exp.sha.5114f85", dict(major="1", minor="0", patch="0", pre="beta", build="exp.sha.5114f85")),
        ("1.0.0+21AF26D3----117B344092BD", dict(major="1", minor="0", patch="0", pre=None, build="21AF26D3----117B344092BD")),
    ],
    ids=short_repr,
)
def test_version_regex(string: str, expected: dict):
    match = VERSION_REGEX.match(string)
    assert match.groupdict() == expected


@pytest.mark.parametrize(
    "string,expected",
    [
        ("1.0.0-alpha", Version(1, 0, 0, "alpha")),
        ("1.0.0-alpha.1", Version(1, 0, 0, "alpha.1")),
        ("1.0.0-0.3.7", Version(1, 0, 0, "0.3.7")),
        ("1.0.0-x.7.z.92", Version(1, 0, 0, "x.7.z.92")),
        ("1.0.0-x-y-z.--", Version(1, 0, 0, "x-y-z.--")),
        ("1.0.0-alpha+001", Version(1, 0, 0, "alpha", "001")),
        ("1.0.0+20130313144700", Version(1, 0, 0, None, "20130313144700")),
        ("1.0.0-beta+exp.sha.5114f85", Version(1, 0, 0, "beta", "exp.sha.5114f85")),
        ("1.0.0+21AF26D3----117B344092BD", Version(1, 0, 0, None, "21AF26D3----117B344092BD")),
        # valid versions from semver.org regular expression:
        # https://regex101.com/r/Ly7O1x/3/
        ("0.0.4", Version(0, 0, 4)),
        ("1.2.3", Version(1, 2, 3)),
        ("10.20.30", Version(10, 20, 30)),
        ("1.1.2+meta", Version(1, 1, 2, None, "meta")),
        ("1.1.2+meta-valid", Version(1, 1, 2, None, "meta-valid")),
        ("1.0.0-alpha", Version(1, 0, 0, "alpha")),
        ("1.0.0-alpha.beta", Version(1, 0, 0, "alpha.beta")),
        ("1.0.0-alpha.beta.1", Version(1, 0, 0, "alpha.beta.1")),
        ("1.0.0-alpha.1", Version(1, 0, 0, "alpha.1")),
        ("1.0.0-alpha0.valid", Version(1, 0, 0, "alpha0.valid")),
        ("1.0.0-alpha.0valid", Version(1, 0, 0, "alpha.0valid")),
        ("1.0.0-alpha-a.b-c-somethinglong+build.1-aef.1-its-okay", Version(1, 0, 0, "alpha-a.b-c-somethinglong", "build.1-aef.1-its-okay")),
        ("1.0.0-rc.1+build.1", Version(1, 0, 0, "rc.1", "build.1")),
        ("2.0.0-rc.1+build.123", Version(2, 0, 0, "rc.1", "build.123")),
        ("10.2.3-DEV-SNAPSHOT", Version(10, 2, 3, "DEV-SNAPSHOT")),
        ("1.2.3-SNAPSHOT-123", Version(1, 2, 3, "SNAPSHOT-123")),
        ("1.0.0", Version(1, 0, 0)),
        ("2.0.0", Version(2, 0, 0)),
        ("1.1.7", Version(1, 1, 7)),
        ("2.0.0+build.1848", Version(2, 0, 0, None, "build.1848")),
        ("2.0.1-alpha.1227", Version(2, 0, 1, "alpha.1227")),
        ("1.0.0-alpha+beta", Version(1, 0, 0, "alpha", "beta")),
        ("1.2.3----RC-SNAPSHOT.12.9.1--.12+788", Version(1, 2, 3, "---RC-SNAPSHOT.12.9.1--.12", "788")),
        ("1.2.3----R-S.12.9.1--.12+meta", Version(1, 2, 3, "---R-S.12.9.1--.12", "meta")),
        ("1.2.3----RC-SNAPSHOT.12.9.1--.12", Version(1, 2, 3, "---RC-SNAPSHOT.12.9.1--.12")),
        ("1.0.0+0.build.1-rc.10000aaa-kk-0.1", Version(1, 0, 0, None, "0.build.1-rc.10000aaa-kk-0.1")),
        (
            "99999999999999999999999.999999999999999999.99999999999999999",
            Version(99999999999999999999999, 999999999999999999, 99999999999999999),
        ),
        ("1.0.0-0A.is.legal", Version(1, 0, 0, "0A.is.legal")),
    ],
    ids=short_repr,
)
def test_parse_version(string: str, expected: Version):
    assert Version.parse(string) == expected


@pytest.mark.parametrize(
    "string",
    [
        "foo",
        "0.0",
        "0-alpha.1",
        "01.2.3",
        "1.02.3",
        "1.2.03",
        # invalid versions from semver.org regular expression:
        # https://regex101.com/r/Ly7O1x/3/
        "1",
        "1.2",
        "1.2.3-0123",
        "1.2.3-0123.0123",
        "1.1.2+.123",
        "+invalid",
        "-invalid",
        "-invalid+invalid",
        "-invalid.01",
        "alpha",
        "alpha.beta",
        "alpha.beta.1",
        "alpha.1",
        "alpha+beta",
        "alpha_beta",
        "alpha.",
        "alpha..",
        "beta",
        "1.0.0-alpha_beta",
        "-alpha.",
        "1.0.0-alpha..",
        "1.0.0-alpha..1",
        "1.0.0-alpha...1",
        "1.0.0-alpha....1",
        "1.0.0-alpha.....1",
        "1.0.0-alpha......1",
        "1.0.0-alpha.......1",
        "01.1.1",
        "1.01.1",
        "1.1.01",
        "1.2",
        "1.2.3.DEV",
        "1.2-SNAPSHOT",
        "1.2.31.2.3----RC-SNAPSHOT.12.09.1--..12+788",
        "1.2-RC-SNAPSHOT",
        "-1.0.3-gamma+b7718",
        "+justmeta",
        "9.8.7+meta+meta",
        "9.8.7-whatever+meta+meta",
        "99999999999999999999999.999999999999999999.99999999999999999----RC-SNAPSHOT.12.09.1--------------------------------..12",
    ],
    ids=short_repr,
)
def test_parse_version_fail(string: str):
    with pytest.raises(ValueError) as exc:
        Version.parse(string)
    assert "Invalid version" in str(exc.value)


@pytest.mark.parametrize(
    "string,version",
    [
        ("0.0.4", Version(0, 0, 4)),
        ("1.2.3", Version(1, 2, 3)),
        ("10.20.30", Version(10, 20, 30)),
        ("1.0.0~alpha", Version(1, 0, 0, "alpha")),
        ("1.0.0~alpha.1", Version(1, 0, 0, "alpha.1")),
        ("1.0.0~0.3.7", Version(1, 0, 0, "0.3.7")),
        ("1.0.0~x.7.z.92", Version(1, 0, 0, "x.7.z.92")),
        ("1.0.0~x_y_z.__", Version(1, 0, 0, "x-y-z.--")),
    ],
    ids=short_repr,
)
def test_version_to_from_rpm(string: str, version: Version):
    parsed = Version.from_rpm(string)
    assert parsed == version
    assert parsed.to_rpm() == string


@pytest.mark.parametrize(
    "string,expected",
    [
        ("1", dict(op=None, major="1", minor=None, patch=None, pre=None)),
        ("1.2", dict(op=None, major="1", minor="2", patch=None, pre=None)),
        ("1.2.3", dict(op=None, major="1", minor="2", patch="3", pre=None)),
        ("1.2.3-alpha.1", dict(op=None, major="1", minor="2", patch="3", pre="alpha.1")),
        ("1.2.3-alpha2", dict(op=None, major="1", minor="2", patch="3", pre="alpha2")),
        ("=0", dict(op="=", major="0", minor=None, patch=None, pre=None)),
        ("=0.11", dict(op="=", major="0", minor="11", patch=None, pre=None)),
        ("=0.1.17", dict(op="=", major="0", minor="1", patch="17", pre=None)),
        ("=0.2.37-alpha.1", dict(op="=", major="0", minor="2", patch="37", pre="alpha.1")),
        ("=0.2.37-alpha2", dict(op="=", major="0", minor="2", patch="37", pre="alpha2")),
        (">1", dict(op=">", major="1", minor=None, patch=None, pre=None)),
        (">1.2", dict(op=">", major="1", minor="2", patch=None, pre=None)),
        (">1.2.3", dict(op=">", major="1", minor="2", patch="3", pre=None)),
        (">1.2.3-alpha.1", dict(op=">", major="1", minor="2", patch="3", pre="alpha.1")),
        (">1.2.3-alpha2", dict(op=">", major="1", minor="2", patch="3", pre="alpha2")),
        (">=0", dict(op=">=", major="0", minor=None, patch=None, pre=None)),
        (">=0.11", dict(op=">=", major="0", minor="11", patch=None, pre=None)),
        (">=0.1.17", dict(op=">=", major="0", minor="1", patch="17", pre=None)),
        (">=0.2.37-alpha.1", dict(op=">=", major="0", minor="2", patch="37", pre="alpha.1")),
        (">=0.2.37-alpha2", dict(op=">=", major="0", minor="2", patch="37", pre="alpha2")),
        ("<1", dict(op="<", major="1", minor=None, patch=None, pre=None)),
        ("<1.2", dict(op="<", major="1", minor="2", patch=None, pre=None)),
        ("<1.2.3", dict(op="<", major="1", minor="2", patch="3", pre=None)),
        ("<1.2.3-alpha.1", dict(op="<", major="1", minor="2", patch="3", pre="alpha.1")),
        ("<1.2.3-alpha2", dict(op="<", major="1", minor="2", patch="3", pre="alpha2")),
        ("<=0", dict(op="<=", major="0", minor=None, patch=None, pre=None)),
        ("<=0.11", dict(op="<=", major="0", minor="11", patch=None, pre=None)),
        ("<=0.1.17", dict(op="<=", major="0", minor="1", patch="17", pre=None)),
        ("<=0.2.37-alpha.1", dict(op="<=", major="0", minor="2", patch="37", pre="alpha.1")),
        ("<=0.2.37-alpha2", dict(op="<=", major="0", minor="2", patch="37", pre="alpha2")),
        ("~1", dict(op="~", major="1", minor=None, patch=None, pre=None)),
        ("~1.2", dict(op="~", major="1", minor="2", patch=None, pre=None)),
        ("~1.2.3", dict(op="~", major="1", minor="2", patch="3", pre=None)),
        ("~1.2.3-alpha.1", dict(op="~", major="1", minor="2", patch="3", pre="alpha.1")),
        ("~1.2.3-alpha2", dict(op="~", major="1", minor="2", patch="3", pre="alpha2")),
        ("^0", dict(op="^", major="0", minor=None, patch=None, pre=None)),
        ("^0.11", dict(op="^", major="0", minor="11", patch=None, pre=None)),
        ("^0.1.17", dict(op="^", major="0", minor="1", patch="17", pre=None)),
        ("^0.2.37-alpha.1", dict(op="^", major="0", minor="2", patch="37", pre="alpha.1")),
        ("^0.2.37-alpha2", dict(op="^", major="0", minor="2", patch="37", pre="alpha2")),
        ("1.*", dict(op=None, major="1", minor="*", patch=None, pre=None)),
        ("1.2.*", dict(op=None, major="1", minor="2", patch="*", pre=None)),
        ("1.*.*", dict(op=None, major="1", minor="*", patch="*", pre=None)),
    ],
    ids=short_repr,
)
def test_version_req_regex(string: str, expected: dict):
    match = VERSION_REQ_REGEX.match(string)
    assert match.groupdict() == expected


@pytest.mark.parametrize(
    "string,expected",
    [
        ("1", Comparator(Op.CARET, 1, None, None, None)),
        ("1.2", Comparator(Op.CARET, 1, 2, None, None)),
        ("1.2.3", Comparator(Op.CARET, 1, 2, 3, None)),
        ("1.2.3-alpha.1", Comparator(Op.CARET, 1, 2, 3, "alpha.1")),
        ("1.2.3-alpha2", Comparator(Op.CARET, 1, 2, 3, "alpha2")),
        ("=0", Comparator(Op.EXACT, 0, None, None, None)),
        ("=0.11", Comparator(Op.EXACT, 0, 11, None, None)),
        ("=0.1.17", Comparator(Op.EXACT, 0, 1, 17, None)),
        ("=0.2.37-alpha.1", Comparator(Op.EXACT, 0, 2, 37, "alpha.1")),
        ("=0.2.37-alpha2", Comparator(Op.EXACT, 0, 2, 37, "alpha2")),
        (">1", Comparator(Op.GREATER, 1, None, None, None)),
        (">1.2", Comparator(Op.GREATER, 1, 2, None, None)),
        (">1.2.3", Comparator(Op.GREATER, 1, 2, 3, None)),
        (">1.2.3-alpha.1", Comparator(Op.GREATER, 1, 2, 3, "alpha.1")),
        (">1.2.3-alpha2", Comparator(Op.GREATER, 1, 2, 3, "alpha2")),
        (">=0", Comparator(Op.GREATER_EQ, 0, None, None, None)),
        (">=0.11", Comparator(Op.GREATER_EQ, 0, 11, None, None)),
        (">=0.1.17", Comparator(Op.GREATER_EQ, 0, 1, 17, None)),
        (">=0.2.37-alpha.1", Comparator(Op.GREATER_EQ, 0, 2, 37, "alpha.1")),
        (">=0.2.37-alpha2", Comparator(Op.GREATER_EQ, 0, 2, 37, "alpha2")),
        ("<1", Comparator(Op.LESS, 1, None, None, None)),
        ("<1.2", Comparator(Op.LESS, 1, 2, None, None)),
        ("<1.2.3", Comparator(Op.LESS, 1, 2, 3, None)),
        ("<1.2.3-alpha.1", Comparator(Op.LESS, 1, 2, 3, "alpha.1")),
        ("<1.2.3-alpha2", Comparator(Op.LESS, 1, 2, 3, "alpha2")),
        ("<=0", Comparator(Op.LESS_EQ, 0, None, None, None)),
        ("<=0.11", Comparator(Op.LESS_EQ, 0, 11, None, None)),
        ("<=0.1.17", Comparator(Op.LESS_EQ, 0, 1, 17, None)),
        ("<=0.2.37-alpha.1", Comparator(Op.LESS_EQ, 0, 2, 37, "alpha.1")),
        ("<=0.2.37-alpha2", Comparator(Op.LESS_EQ, 0, 2, 37, "alpha2")),
        ("~1", Comparator(Op.TILDE, 1, None, None, None)),
        ("~1.2", Comparator(Op.TILDE, 1, 2, None, None)),
        ("~1.2.3", Comparator(Op.TILDE, 1, 2, 3, None)),
        ("~1.2.3-alpha.1", Comparator(Op.TILDE, 1, 2, 3, "alpha.1")),
        ("~1.2.3-alpha2", Comparator(Op.TILDE, 1, 2, 3, "alpha2")),
        ("^0", Comparator(Op.CARET, 0, None, None, None)),
        ("^0.11", Comparator(Op.CARET, 0, 11, None, None)),
        ("^0.1.17", Comparator(Op.CARET, 0, 1, 17, None)),
        ("^0.2.37-alpha.1", Comparator(Op.CARET, 0, 2, 37, "alpha.1")),
        ("^0.2.37-alpha2", Comparator(Op.CARET, 0, 2, 37, "alpha2")),
        ("1.*", Comparator(Op.WILDCARD, 1, None, None, None)),
        ("1.*.*", Comparator(Op.WILDCARD, 1, None, None, None)),
        ("1.2.*", Comparator(Op.WILDCARD, 1, 2, None, None)),
    ],
    ids=short_repr,
)
def test_parse_comparator(string: str, expected: Comparator):
    assert Comparator.parse(string) == expected


@pytest.mark.parametrize(
    "string,expected_exc,expected_err",
    [
        ("foo", ValueError, "Invalid version requirement"),
        ("0.*.0", ValueError, "Invalid wildcard requirement"),
        ("0-alpha.1", ValueError, "Invalid pre-release requirement"),
        ("01.2.3", ValueError, "Invalid version requirement"),
        ("1.02.3", ValueError, "Invalid version requirement"),
        ("1.2.03", ValueError, "Invalid version requirement"),
    ],
    ids=short_repr,
)
def test_parse_comparator_fail(string: str, expected_exc, expected_err: str):
    with pytest.raises(expected_exc) as exc:
        Comparator.parse(string)
    assert expected_err in str(exc.value)


@pytest.mark.parametrize(
    "string,expected",
    [
        ("^0.1", VersionReq([Comparator(Op.CARET, 0, 1, None, None)])),
        ("~0.1", VersionReq([Comparator(Op.TILDE, 0, 1, None, None)])),
        ("^1.2", VersionReq([Comparator(Op.CARET, 1, 2, None, None)])),
        ("~1.2", VersionReq([Comparator(Op.TILDE, 1, 2, None, None)])),
        (">=1.2.3, <2.0.0", VersionReq([Comparator(Op.GREATER_EQ, 1, 2, 3, None), Comparator(Op.LESS, 2, 0, 0, None)])),
        (">=0.1.7, <0.2.0", VersionReq([Comparator(Op.GREATER_EQ, 0, 1, 7, None), Comparator(Op.LESS, 0, 2, 0, None)])),
        ("*", VersionReq([])),
    ],
    ids=short_repr,
)
def test_parse_version_req(string: str, expected: VersionReq):
    assert VersionReq.parse(string) == expected


def test_parse_version_req_fail():
    with pytest.raises(ValueError) as exc:
        VersionReq.parse("")
    assert "Invalid version requirement (empty string)" in str(exc.value)


@pytest.mark.parametrize(
    "string,expected",
    [
        ("=1.2.3", [Comparator(Op.EXACT, 1, 2, 3, None)]),
        ("=1.2", [Comparator(Op.GREATER_EQ, 1, 2, 0, None), Comparator(Op.LESS, 1, 3, 0, None)]),
        ("=1", [Comparator(Op.GREATER_EQ, 1, 0, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        (">1.2.3", [Comparator(Op.GREATER, 1, 2, 3, None)]),
        (">1.2", [Comparator(Op.GREATER_EQ, 1, 3, 0, None)]),
        (">1", [Comparator(Op.GREATER_EQ, 2, 0, 0, None)]),
        (">=1.2.3", [Comparator(Op.GREATER_EQ, 1, 2, 3, None)]),
        (">=1.2", [Comparator(Op.GREATER_EQ, 1, 2, 0, None)]),
        (">=1", [Comparator(Op.GREATER_EQ, 1, 0, 0, None)]),
        ("<1.2.3", [Comparator(Op.LESS, 1, 2, 3, None)]),
        ("<1.2", [Comparator(Op.LESS, 1, 2, 0, None)]),
        ("<1", [Comparator(Op.LESS, 1, 0, 0, None)]),
        ("<=1.2.3", [Comparator(Op.LESS_EQ, 1, 2, 3, None)]),
        ("<=1.2", [Comparator(Op.LESS, 1, 3, 0, None)]),
        ("<=1", [Comparator(Op.LESS, 2, 0, 0, None)]),
        ("~1.2.3", [Comparator(Op.GREATER_EQ, 1, 2, 3, None), Comparator(Op.LESS, 1, 3, 0, None)]),
        ("~1.2", [Comparator(Op.GREATER_EQ, 1, 2, 0, None), Comparator(Op.LESS, 1, 3, 0, None)]),
        ("~1", [Comparator(Op.GREATER_EQ, 1, 0, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        ("^1.2.3", [Comparator(Op.GREATER_EQ, 1, 2, 3, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        ("^0.1.2", [Comparator(Op.GREATER_EQ, 0, 1, 2, None), Comparator(Op.LESS, 0, 2, 0, None)]),
        ("^0.0.1", [Comparator(Op.EXACT, 0, 0, 1, None)]),
        ("^1.2", [Comparator(Op.GREATER_EQ, 1, 2, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        ("^0.1", [Comparator(Op.GREATER_EQ, 0, 1, 0, None), Comparator(Op.LESS, 0, 2, 0, None)]),
        ("^0.0", [Comparator(Op.GREATER_EQ, 0, 0, 0, None), Comparator(Op.LESS, 0, 1, 0, None)]),
        ("^1", [Comparator(Op.GREATER_EQ, 1, 0, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        ("1.2.*", [Comparator(Op.GREATER_EQ, 1, 2, 0, None), Comparator(Op.LESS, 1, 3, 0, None)]),
        ("1.*", [Comparator(Op.GREATER_EQ, 1, 0, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
        ("1.*.*", [Comparator(Op.GREATER_EQ, 1, 0, 0, None), Comparator(Op.LESS, 2, 0, 0, None)]),
    ],
    ids=short_repr,
)
def test_normalize_comparator(string: str, expected: List[Comparator]):
    assert Comparator.parse(string).normalize() == expected


@pytest.mark.parametrize(
    "comparator,feature,expected",
    [
        ("=1.2.3", None, "crate(foo) = 1.2.3"),
        ("=1.2.3", "default", "crate(foo/default) = 1.2.3"),
        (">1.2.3", None, "crate(foo) > 1.2.3"),
        (">1.2.3", "default", "crate(foo/default) > 1.2.3"),
        (">=1.2.3", None, "crate(foo) >= 1.2.3"),
        (">=1.2.3", "default", "crate(foo/default) >= 1.2.3"),
        ("<1.2.3", None, "crate(foo) < 1.2.3~"),
        ("<1.2.3", "default", "crate(foo/default) < 1.2.3~"),
        ("<=1.2.3", None, "crate(foo) <= 1.2.3"),
        ("<=1.2.3", "default", "crate(foo/default) <= 1.2.3"),
    ],
    ids=short_repr,
)
def test_comparator_to_rpm(comparator: str, feature: Optional[str], expected: str):
    assert Comparator.parse(comparator).to_rpm("foo", feature) == expected


@pytest.mark.parametrize(
    "req,feature,expected",
    [
        ("*", None, "crate(foo)"),
        ("*", "default", "crate(foo/default)"),
        ("=1.2.3", None, "crate(foo) = 1.2.3"),
        ("=1.2.3", "default", "crate(foo/default) = 1.2.3"),
        ("=1.2", None, "(crate(foo) >= 1.2.0 with crate(foo) < 1.3.0~)"),
        ("=1.2", "default", "(crate(foo/default) >= 1.2.0 with crate(foo/default) < 1.3.0~)"),
        ("=1", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("=1", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        (">1.2.3", None, "crate(foo) > 1.2.3"),
        (">1.2.3", "default", "crate(foo/default) > 1.2.3"),
        (">1.2", None, "crate(foo) >= 1.3.0"),
        (">1.2", "default", "crate(foo/default) >= 1.3.0"),
        (">1", None, "crate(foo) >= 2.0.0"),
        (">1", "default", "crate(foo/default) >= 2.0.0"),
        (">=1.2.3", None, "crate(foo) >= 1.2.3"),
        (">=1.2.3", "default", "crate(foo/default) >= 1.2.3"),
        (">=1.2", None, "crate(foo) >= 1.2.0"),
        (">=1.2", "default", "crate(foo/default) >= 1.2.0"),
        (">=1", None, "crate(foo) >= 1.0.0"),
        (">=1", "default", "crate(foo/default) >= 1.0.0"),
        ("<1.2.3", None, "crate(foo) < 1.2.3~"),
        ("<1.2.3", "default", "crate(foo/default) < 1.2.3~"),
        ("<1.2", None, "crate(foo) < 1.2.0~"),
        ("<1.2", "default", "crate(foo/default) < 1.2.0~"),
        ("<1", None, "crate(foo) < 1.0.0~"),
        ("<1", "default", "crate(foo/default) < 1.0.0~"),
        ("<=1.2.3", None, "crate(foo) <= 1.2.3"),
        ("<=1.2.3", "default", "crate(foo/default) <= 1.2.3"),
        ("<=1.2", None, "crate(foo) < 1.3.0~"),
        ("<=1.2", "default", "crate(foo/default) < 1.3.0~"),
        ("<=1", None, "crate(foo) < 2.0.0~"),
        ("<=1", "default", "crate(foo/default) < 2.0.0~"),
        ("~1.2.3", None, "(crate(foo) >= 1.2.3 with crate(foo) < 1.3.0~)"),
        ("~1.2.3", "default", "(crate(foo/default) >= 1.2.3 with crate(foo/default) < 1.3.0~)"),
        ("~1.2", None, "(crate(foo) >= 1.2.0 with crate(foo) < 1.3.0~)"),
        ("~1.2", "default", "(crate(foo/default) >= 1.2.0 with crate(foo/default) < 1.3.0~)"),
        ("~1", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("~1", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        ("^1.2.3", None, "(crate(foo) >= 1.2.3 with crate(foo) < 2.0.0~)"),
        ("^1.2.3", "default", "(crate(foo/default) >= 1.2.3 with crate(foo/default) < 2.0.0~)"),
        ("^0.1.2", None, "(crate(foo) >= 0.1.2 with crate(foo) < 0.2.0~)"),
        ("^0.1.2", "default", "(crate(foo/default) >= 0.1.2 with crate(foo/default) < 0.2.0~)"),
        ("^0.0.1", None, "crate(foo) = 0.0.1"),
        ("^0.0.1", "default", "crate(foo/default) = 0.0.1"),
        ("^1.2", None, "(crate(foo) >= 1.2.0 with crate(foo) < 2.0.0~)"),
        ("^1.2", "default", "(crate(foo/default) >= 1.2.0 with crate(foo/default) < 2.0.0~)"),
        ("^0.1", None, "(crate(foo) >= 0.1.0 with crate(foo) < 0.2.0~)"),
        ("^0.1", "default", "(crate(foo/default) >= 0.1.0 with crate(foo/default) < 0.2.0~)"),
        ("^0.0", None, "(crate(foo) >= 0.0.0 with crate(foo) < 0.1.0~)"),
        ("^0.0", "default", "(crate(foo/default) >= 0.0.0 with crate(foo/default) < 0.1.0~)"),
        ("^1", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("^1", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        ("1.2.3", None, "(crate(foo) >= 1.2.3 with crate(foo) < 2.0.0~)"),
        ("1.2.3", "default", "(crate(foo/default) >= 1.2.3 with crate(foo/default) < 2.0.0~)"),
        ("0.1.2", None, "(crate(foo) >= 0.1.2 with crate(foo) < 0.2.0~)"),
        ("0.1.2", "default", "(crate(foo/default) >= 0.1.2 with crate(foo/default) < 0.2.0~)"),
        ("0.0.1", None, "crate(foo) = 0.0.1"),
        ("0.0.1", "default", "crate(foo/default) = 0.0.1"),
        ("1.2", None, "(crate(foo) >= 1.2.0 with crate(foo) < 2.0.0~)"),
        ("1.2", "default", "(crate(foo/default) >= 1.2.0 with crate(foo/default) < 2.0.0~)"),
        ("0.1", None, "(crate(foo) >= 0.1.0 with crate(foo) < 0.2.0~)"),
        ("0.1", "default", "(crate(foo/default) >= 0.1.0 with crate(foo/default) < 0.2.0~)"),
        ("0.0", None, "(crate(foo) >= 0.0.0 with crate(foo) < 0.1.0~)"),
        ("0.0", "default", "(crate(foo/default) >= 0.0.0 with crate(foo/default) < 0.1.0~)"),
        ("1", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("1", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        ("1.2.*", None, "(crate(foo) >= 1.2.0 with crate(foo) < 1.3.0~)"),
        ("1.2.*", "default", "(crate(foo/default) >= 1.2.0 with crate(foo/default) < 1.3.0~)"),
        ("1.*", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("1.*", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        ("1.*.*", None, "(crate(foo) >= 1.0.0 with crate(foo) < 2.0.0~)"),
        ("1.*.*", "default", "(crate(foo/default) >= 1.0.0 with crate(foo/default) < 2.0.0~)"),
        # some real-world test cases with pre-releases
        ("^0.1.0-alpha.4", "default", "(crate(foo/default) >= 0.1.0~alpha.4 with crate(foo/default) < 0.2.0~)"),
        ("=1.0.0-alpha.5", "default", "crate(foo/default) = 1.0.0~alpha.5"),
    ],
    ids=short_repr,
)
def test_version_req_to_rpm(req: str, feature: Optional[str], expected: str):
    assert VersionReq.parse(req).to_rpm("foo", feature) == expected


def test_version_req_to_rpm_fail():
    with pytest.raises(ValueError) as exc:
        VersionReq.parse(">=0.1.0, <0.2.0, >=0.3.0, <1.0.0").to_rpm("foo", None)
    assert "Using more than 2 comparators is not supported by RPM." in str(exc.value)
