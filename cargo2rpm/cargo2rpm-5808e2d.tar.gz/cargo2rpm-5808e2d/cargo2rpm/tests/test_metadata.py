from typing import Dict, Optional, Set

from cargo2rpm.metadata import FeatureFlags
from cargo2rpm.utils import load_metadata_from_resource, short_repr

import pytest


@pytest.mark.parametrize(
    "filename",
    [
        "ahash-0.8.3.json",
        "assert_cmd-2.0.8.json",
        "assert_fs-1.0.10.json",
        "autocfg-1.1.0.json",
        "bstr-1.2.0.json",
        "cfg-if-1.0.0.json",
        "clap-4.1.4.json",
        "fapolicy-analyzer-0.6.8.json",
        "gstreamer-0.19.7.json",
        "human-panic-1.1.0.json",
        "hyperfine-1.15.0.json",
        "libblkio-1.2.2.json",
        "libc-0.2.139.json",
        "predicates-2.1.5.json",
        "proc-macro2-1.0.50.json",
        "quote-1.0.23.json",
        "rand-0.8.5.json",
        "rand_core-0.6.4.json",
        "rpm-sequoia-1.2.0.json",
        "rust_decimal-1.28.0.json",
        "rustix-0.36.8.json",
        "serde-1.0.152.json",
        "serde_derive-1.0.152.json",
        "syn-1.0.107.json",
        "time-0.3.17.json",
        "tokio-1.25.0.json",
        "unicode-xid-0.2.4.json",
        "zbus-3.8.0.json",
        "zola-0.16.1.json",
        "zoxide-0.9.0.json",
    ],
    ids=short_repr,
)
def test_metadata_smoke(filename: str):
    metadata = load_metadata_from_resource(filename)
    packages = metadata.packages()
    assert len(packages) >= 1


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("ahash-0.8.3.json", False),
        ("assert_cmd-2.0.8.json", True),
        ("assert_fs-1.0.10.json", False),
        ("autocfg-1.1.0.json", False),
        ("bstr-1.2.0.json", False),
        ("cfg-if-1.0.0.json", False),
        ("clap-4.1.4.json", True),
        ("fapolicy-analyzer-0.6.8.json", True),
        ("gstreamer-0.19.7.json", False),
        ("human-panic-1.1.0.json", False),
        ("hyperfine-1.15.0.json", True),
        ("libblkio-1.2.2.json", False),
        ("libc-0.2.139.json", False),
        ("predicates-2.1.5.json", False),
        ("proc-macro2-1.0.50.json", False),
        ("quote-1.0.23.json", False),
        ("rand-0.8.5.json", False),
        ("rand_core-0.6.4.json", False),
        ("rpm-sequoia-1.2.0.json", False),
        ("rust_decimal-1.28.0.json", False),
        ("rustix-0.36.8.json", False),
        ("serde-1.0.152.json", False),
        ("serde_derive-1.0.152.json", False),
        ("syn-1.0.107.json", False),
        ("time-0.3.17.json", False),
        ("tokio-1.25.0.json", False),
        ("unicode-xid-0.2.4.json", False),
        ("zbus-3.8.0.json", False),
        ("zola-0.16.1.json", True),
        ("zoxide-0.9.0.json", True),
    ],
    ids=short_repr,
)
def test_metadata_is_bin(filename: str, expected):
    metadata = load_metadata_from_resource(filename)
    assert metadata.is_bin() == expected


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("ahash-0.8.3.json", True),
        ("assert_cmd-2.0.8.json", True),
        ("assert_fs-1.0.10.json", True),
        ("autocfg-1.1.0.json", True),
        ("bstr-1.2.0.json", True),
        ("cfg-if-1.0.0.json", True),
        ("clap-4.1.4.json", True),
        ("fapolicy-analyzer-0.6.8.json", False),
        ("gstreamer-0.19.7.json", True),
        ("human-panic-1.1.0.json", True),
        ("hyperfine-1.15.0.json", False),
        ("libblkio-1.2.2.json", False),
        ("libc-0.2.139.json", True),
        ("predicates-2.1.5.json", True),
        ("proc-macro2-1.0.50.json", True),
        ("quote-1.0.23.json", True),
        ("rand-0.8.5.json", True),
        ("rand_core-0.6.4.json", True),
        ("rpm-sequoia-1.2.0.json", False),
        ("rust_decimal-1.28.0.json", True),
        ("rustix-0.36.8.json", True),
        ("serde-1.0.152.json", True),
        ("serde_derive-1.0.152.json", True),
        ("syn-1.0.107.json", True),
        ("time-0.3.17.json", True),
        ("tokio-1.25.0.json", True),
        ("unicode-xid-0.2.4.json", True),
        ("zbus-3.8.0.json", True),
        ("zola-0.16.1.json", False),
        ("zoxide-0.9.0.json", False),
    ],
    ids=short_repr,
)
def test_metadata_is_lib(filename: str, expected: bool):
    metadata = load_metadata_from_resource(filename)
    assert metadata.is_lib() == expected


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("ahash-0.8.3.json", False),
        ("assert_cmd-2.0.8.json", False),
        ("assert_fs-1.0.10.json", False),
        ("autocfg-1.1.0.json", False),
        ("bstr-1.2.0.json", False),
        ("cfg-if-1.0.0.json", False),
        ("clap-4.1.4.json", False),
        ("fapolicy-analyzer-0.6.8.json", True),
        ("gstreamer-0.19.7.json", False),
        ("human-panic-1.1.0.json", False),
        ("hyperfine-1.15.0.json", False),
        ("libblkio-1.2.2.json", True),
        ("libc-0.2.139.json", False),
        ("predicates-2.1.5.json", False),
        ("proc-macro2-1.0.50.json", False),
        ("quote-1.0.23.json", False),
        ("rand-0.8.5.json", False),
        ("rand_core-0.6.4.json", False),
        ("rpm-sequoia-1.2.0.json", False),
        ("rust_decimal-1.28.0.json", False),
        ("rustix-0.36.8.json", False),
        ("serde-1.0.152.json", False),
        ("serde_derive-1.0.152.json", False),
        ("syn-1.0.107.json", False),
        ("time-0.3.17.json", False),
        ("tokio-1.25.0.json", False),
        ("unicode-xid-0.2.4.json", False),
        ("zbus-3.8.0.json", False),
        ("zola-0.16.1.json", True),
        ("zoxide-0.9.0.json", False),
    ],
    ids=short_repr,
)
def test_metadata_is_workspace(filename: str, expected: bool):
    metadata = load_metadata_from_resource(filename)
    assert metadata.is_workspace() == expected


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("ahash-0.8.3.json", set()),
        ("assert_cmd-2.0.8.json", {"bin_fixture"}),
        ("assert_fs-1.0.10.json", set()),
        ("autocfg-1.1.0.json", set()),
        ("bstr-1.2.0.json", set()),
        ("cfg-if-1.0.0.json", set()),
        ("clap-4.1.4.json", {"stdio-fixture"}),
        ("fapolicy-analyzer-0.6.8.json", {"tdb", "rulec"}),
        ("gstreamer-0.19.7.json", set()),
        ("human-panic-1.1.0.json", set()),
        ("hyperfine-1.15.0.json", {"hyperfine"}),
        ("libblkio-1.2.2.json", set()),
        ("libc-0.2.139.json", set()),
        ("predicates-2.1.5.json", set()),
        ("proc-macro2-1.0.50.json", set()),
        ("quote-1.0.23.json", set()),
        ("rand-0.8.5.json", set()),
        ("rand_core-0.6.4.json", set()),
        ("rpm-sequoia-1.2.0.json", set()),
        ("rust_decimal-1.28.0.json", set()),
        ("rustix-0.36.8.json", set()),
        ("serde-1.0.152.json", set()),
        ("serde_derive-1.0.152.json", set()),
        ("syn-1.0.107.json", set()),
        ("time-0.3.17.json", set()),
        ("tokio-1.25.0.json", set()),
        ("unicode-xid-0.2.4.json", set()),
        ("zbus-3.8.0.json", set()),
        ("zola-0.16.1.json", {"zola"}),
        ("zoxide-0.9.0.json", {"zoxide"}),
    ],
    ids=short_repr,
)
def test_metadata_get_binaries(filename: str, expected: Set[str]):
    metadata = load_metadata_from_resource(filename)
    assert metadata.get_binaries() == expected


@pytest.mark.parametrize(
    "filename,flags,expected_enabled,expected_optional,expected_other,expected_conditional",
    [
        # default features
        ("ahash-0.8.3.json", FeatureFlags(), {"default", "std", "runtime-rng", "getrandom"}, {"getrandom"}, dict(), dict()),
        # all features
        (
            "ahash-0.8.3.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "std",
                "runtime-rng",
                "getrandom",
                "atomic-polyfill",
                "compile-time-rng",
                "const-random",
                "no-rng",
                "serde",
            },
            {
                "atomic-polyfill",
                "const-random",
                "getrandom",
                "serde",
            },
            {"once_cell": {"atomic-polyfill"}},
            dict(),
        ),
        # no default features
        ("ahash-0.8.3.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + compile-time-rng
        (
            "ahash-0.8.3.json",
            FeatureFlags(features=["compile-time-rng"]),
            {"default", "std", "runtime-rng", "getrandom", "compile-time-rng", "const-random"},
            {"const-random", "getrandom"},
            dict(),
            dict(),
        ),
        # no default features + compile-time-rng
        (
            "ahash-0.8.3.json",
            FeatureFlags(no_default_features=True, features=["compile-time-rng"]),
            {"compile-time-rng", "const-random"},
            {"const-random"},
            dict(),
            dict(),
        ),
        # default features
        ("assert_cmd-2.0.8.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        (
            "assert_cmd-2.0.8.json",
            FeatureFlags(all_features=True),
            {"color", "color-auto"},
            {"concolor", "yansi"},
            {"predicates": {"color"}},
            {"concolor": {"std", "auto"}},
        ),
        # no default features
        ("assert_cmd-2.0.8.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + color
        (
            "assert_cmd-2.0.8.json",
            FeatureFlags(features=["color"]),
            {"color"},
            {"concolor", "yansi"},
            {"predicates": {"color"}},
            {"concolor": {"std"}},
        ),
        # no default features + color
        (
            "assert_cmd-2.0.8.json",
            FeatureFlags(no_default_features=True, features=["color"]),
            {"color"},
            {"concolor", "yansi"},
            {"predicates": {"color"}},
            {"concolor": {"std"}},
        ),
        # default features
        ("assert_fs-1.0.10.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        (
            "assert_fs-1.0.10.json",
            FeatureFlags(all_features=True),
            {"color", "color-auto"},
            {"concolor", "yansi"},
            {"predicates": {"color"}},
            {"concolor": {"auto"}},
        ),
        # no default features
        ("assert_fs-1.0.10.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + color
        ("assert_fs-1.0.10.json", FeatureFlags(features=["color"]), {"color"}, {"concolor", "yansi"}, {"predicates": {"color"}}, dict()),
        # no default features + color
        (
            "assert_fs-1.0.10.json",
            FeatureFlags(no_default_features=True, features=["color"]),
            {"color"},
            {"concolor", "yansi"},
            {"predicates": {"color"}},
            dict(),
        ),
        # default features
        ("autocfg-1.1.0.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        ("autocfg-1.1.0.json", FeatureFlags(all_features=True), set(), set(), dict(), dict()),
        # no default features
        ("autocfg-1.1.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "bstr-1.2.0.json",
            FeatureFlags(),
            {"default", "std", "unicode", "alloc"},
            {"once_cell", "regex-automata"},
            {"memchr": {"std"}},
            {"serde": {"alloc", "std"}},
        ),
        # all features
        (
            "bstr-1.2.0.json",
            FeatureFlags(all_features=True),
            {"default", "alloc", "serde", "std", "unicode"},
            {"serde", "once_cell", "regex-automata"},
            {"memchr": {"std"}},
            {"serde": {"alloc", "std"}},
        ),
        # no default features
        ("bstr-1.2.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + serde
        (
            "bstr-1.2.0.json",
            FeatureFlags(features=["serde"]),
            {"default", "std", "unicode", "alloc", "serde"},
            {"once_cell", "regex-automata", "serde"},
            {"memchr": {"std"}},
            {"serde": {"alloc", "std"}},
        ),
        # no default features + serde
        (
            "bstr-1.2.0.json",
            FeatureFlags(no_default_features=True, features=["serde"]),
            {"serde"},
            {"serde"},
            dict(),
            dict(),
        ),
        # default features
        ("cfg-if-1.0.0.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        (
            "cfg-if-1.0.0.json",
            FeatureFlags(all_features=True),
            {"compiler_builtins", "core", "rustc-dep-of-std"},
            {"compiler_builtins", "core"},
            dict(),
            dict(),
        ),
        # no default features
        ("cfg-if-1.0.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "clap-4.1.4.json",
            FeatureFlags(),
            {"default", "std", "color", "help", "usage", "error-context", "suggestions"},
            {"is-terminal", "termcolor", "strsim"},
            dict(),
            dict(),
        ),
        # all features
        (
            "clap-4.1.4.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "cargo",
                "color",
                "debug",
                "deprecated",
                "derive",
                "env",
                "error-context",
                "help",
                "std",
                "string",
                "suggestions",
                "unicode",
                "unstable-doc",
                "unstable-grouped",
                "unstable-replace",
                "unstable-v5",
                "usage",
                "wrap_help",
            },
            {"once_cell", "is-terminal", "termcolor", "backtrace", "clap_derive", "strsim", "unicode-width", "unicase", "terminal_size"},
            dict(),
            {"clap_derive": {"debug", "deprecated", "unstable-v5"}},
        ),
        # no default features
        ("clap-4.1.4.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + wrap_help
        (
            "clap-4.1.4.json",
            FeatureFlags(features=["wrap_help"]),
            {"default", "std", "color", "help", "usage", "error-context", "suggestions", "wrap_help"},
            {"is-terminal", "termcolor", "strsim", "terminal_size"},
            dict(),
            dict(),
        ),
        # no default features + wrap_help
        (
            "clap-4.1.4.json",
            FeatureFlags(no_default_features=True, features=["wrap_help"]),
            {"wrap_help", "help"},
            {"terminal_size"},
            dict(),
            dict(),
        ),
        # default features
        (
            "gstreamer-0.19.7.json",
            FeatureFlags(),
            {"default"},
            set(),
            dict(),
            dict(),
        ),
        # all features
        (
            "gstreamer-0.19.7.json",
            FeatureFlags(all_features=True),
            {"default", "dox", "serde", "serde_bytes", "v1_16", "v1_18", "v1_20", "v1_22"},
            {"serde", "serde_bytes"},
            {"ffi": {"dox", "v1_16", "v1_18", "v1_20", "v1_22"}, "glib": {"dox"}, "num-rational": {"serde"}},
            dict(),
        ),
        # no default features
        ("gstreamer-0.19.7.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + serde
        (
            "gstreamer-0.19.7.json",
            FeatureFlags(features=["serde"]),
            {"default", "serde", "serde_bytes"},
            {"serde", "serde_bytes"},
            {"num-rational": {"serde"}},
            dict(),
        ),
        # no default features + serde
        (
            "gstreamer-0.19.7.json",
            FeatureFlags(no_default_features=True, features=["serde"]),
            {"serde", "serde_bytes"},
            {"serde", "serde_bytes"},
            {"num-rational": {"serde"}},
            dict(),
        ),
        # default features
        (
            "human-panic-1.1.0.json",
            FeatureFlags(),
            {"default", "color"},
            {"concolor", "termcolor"},
            dict(),
            dict(),
        ),
        # all features
        (
            "human-panic-1.1.0.json",
            FeatureFlags(all_features=True),
            {"default", "color", "nightly"},
            {"concolor", "termcolor"},
            dict(),
            dict(),
        ),
        # no default features
        ("human-panic-1.1.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + nightly
        (
            "human-panic-1.1.0.json",
            FeatureFlags(features=["nightly"]),
            {"default", "color", "nightly"},
            {"concolor", "termcolor"},
            dict(),
            dict(),
        ),
        # no default features + nightly
        (
            "human-panic-1.1.0.json",
            FeatureFlags(no_default_features=True, features=["nightly"]),
            {"nightly"},
            set(),
            dict(),
            dict(),
        ),
        # default features
        ("hyperfine-1.15.0.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        (
            "hyperfine-1.15.0.json",
            FeatureFlags(all_features=True),
            {"windows_process_extensions_main_thread_handle"},
            set(),
            dict(),
            dict(),
        ),
        # no default features
        ("hyperfine-1.15.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        ("libc-0.2.139.json", FeatureFlags(), {"default", "std"}, set(), dict(), dict()),
        # all features
        (
            "libc-0.2.139.json",
            FeatureFlags(all_features=True),
            {"default", "align", "const-extern-fn", "extra_traits", "rustc-dep-of-std", "rustc-std-workspace-core", "std", "use_std"},
            {"rustc-std-workspace-core"},
            dict(),
            dict(),
        ),
        # no default features
        ("libc-0.2.139.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + align
        (
            "libc-0.2.139.json",
            FeatureFlags(features=["align"]),
            {"default", "std", "align"},
            set(),
            dict(),
            dict(),
        ),
        # no default features + align
        ("libc-0.2.139.json", FeatureFlags(no_default_features=True, features=["align"]), {"align"}, set(), dict(), dict()),
        # default features
        (
            "predicates-2.1.5.json",
            FeatureFlags(),
            {"default", "diff", "regex", "float-cmp", "normalize-line-endings"},
            {"difflib", "regex", "float-cmp", "normalize-line-endings"},
            dict(),
            dict(),
        ),
        # all features
        (
            "predicates-2.1.5.json",
            FeatureFlags(all_features=True),
            {"default", "color", "color-auto", "diff", "float-cmp", "normalize-line-endings", "regex", "unstable"},
            {"yansi", "concolor", "difflib", "float-cmp", "normalize-line-endings", "regex"},
            dict(),
            {"concolor": {"auto", "std"}},
        ),
        # no default features
        ("predicates-2.1.5.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + color
        (
            "predicates-2.1.5.json",
            FeatureFlags(features=["color"]),
            {"default", "diff", "regex", "float-cmp", "normalize-line-endings", "color"},
            {"difflib", "regex", "float-cmp", "normalize-line-endings", "yansi", "concolor"},
            dict(),
            {"concolor": {"std"}},
        ),
        # no default features + color
        (
            "predicates-2.1.5.json",
            FeatureFlags(no_default_features=True, features=["color"]),
            {"color"},
            {"yansi", "concolor"},
            dict(),
            {"concolor": {"std"}},
        ),
        # default features
        ("proc-macro2-1.0.50.json", FeatureFlags(), {"default", "proc-macro"}, set(), dict(), dict()),
        # all features
        (
            "proc-macro2-1.0.50.json",
            FeatureFlags(all_features=True),
            {"default", "nightly", "proc-macro", "span-locations"},
            set(),
            dict(),
            dict(),
        ),
        # no default features
        ("proc-macro2-1.0.50.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + span-locations
        (
            "proc-macro2-1.0.50.json",
            FeatureFlags(features=["span-locations"]),
            {"default", "proc-macro", "span-locations"},
            set(),
            dict(),
            dict(),
        ),
        # no default features + span-locations
        (
            "proc-macro2-1.0.50.json",
            FeatureFlags(no_default_features=True, features=["span-locations"]),
            {"span-locations"},
            set(),
            dict(),
            dict(),
        ),
        # default features
        ("quote-1.0.23.json", FeatureFlags(), {"default", "proc-macro"}, set(), {"proc-macro2": {"proc-macro"}}, dict()),
        # all features
        (
            "quote-1.0.23.json",
            FeatureFlags(all_features=True),
            {"default", "proc-macro"},
            set(),
            {"proc-macro2": {"proc-macro"}},
            dict(),
        ),
        # no default features
        ("quote-1.0.23.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "rand-0.8.5.json",
            FeatureFlags(),
            {"default", "std", "std_rng", "alloc", "getrandom", "libc", "rand_chacha"},
            {"libc", "rand_chacha"},
            {"rand_core": {"alloc", "getrandom", "std"}, "rand_chacha": {"std"}},
            dict(),
        ),
        # all features
        (
            "rand-0.8.5.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "alloc",
                "getrandom",
                "libc",
                "log",
                "min_const_gen",
                "nightly",
                "packed_simd",
                "rand_chacha",
                "serde",
                "serde1",
                "simd_support",
                "small_rng",
                "std",
                "std_rng",
            },
            {"libc", "log", "packed_simd", "rand_chacha", "serde"},
            {"rand_core": {"alloc", "getrandom", "serde1", "std"}, "rand_chacha": {"std"}},
            dict(),
        ),
        # no default features
        ("rand-0.8.5.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + serde1
        (
            "rand-0.8.5.json",
            FeatureFlags(features=["serde1"]),
            {"default", "std", "std_rng", "alloc", "getrandom", "libc", "rand_chacha", "serde1", "serde"},
            {"libc", "rand_chacha", "serde"},
            {"rand_core": {"alloc", "getrandom", "std", "serde1"}, "rand_chacha": {"std"}},
            dict(),
        ),
        # no default features + serde1
        (
            "rand-0.8.5.json",
            FeatureFlags(no_default_features=True, features=["serde1"]),
            {"serde1", "serde"},
            {"serde"},
            {"rand_core": {"serde1"}},
            dict(),
        ),
        # default features
        ("rand_core-0.6.4.json", FeatureFlags(), set(), set(), dict(), dict()),
        # all features
        (
            "rand_core-0.6.4.json",
            FeatureFlags(all_features=True),
            {"alloc", "getrandom", "serde", "serde1", "std"},
            {"getrandom", "serde"},
            {"getrandom": {"std"}},
            dict(),
        ),
        # no default features
        ("rand_core-0.6.4.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "rust_decimal-1.28.0.json",
            FeatureFlags(),
            {"default", "serde", "std"},
            {"serde"},
            {"arrayvec": {"std"}},
            {
                "borsh": {"std"},
                "bytecheck": {"std"},
                "byteorder": {"std"},
                "bytes": {"std"},
                "rand": {"std"},
                "rkyv": {"std"},
                "serde": {"std"},
                "serde_json": {"std"},
            },
        ),
        # all features
        (
            "rust_decimal-1.28.0.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "arbitrary",
                "borsh",
                "bytecheck",
                "byteorder",
                "bytes",
                "c-repr",
                "db-diesel-mysql",
                "db-diesel-postgres",
                "db-diesel1-mysql",
                "db-diesel1-postgres",
                "db-diesel2-mysql",
                "db-diesel2-postgres",
                "db-postgres",
                "db-tokio-postgres",
                "diesel1",
                "diesel2",
                "legacy-ops",
                "maths",
                "maths-nopanic",
                "postgres",
                "rand",
                "rkyv",
                "rkyv-safe",
                "rocket",
                "rocket-traits",
                "rust-fuzz",
                "serde",
                "serde-arbitrary-precision",
                "serde-bincode",
                "serde-float",
                "serde-str",
                "serde-with-arbitrary-precision",
                "serde-with-float",
                "serde-with-str",
                "serde_json",
                "std",
                "tokio-pg",
                "tokio-postgres",
            },
            {
                "arbitrary",
                "borsh",
                "bytecheck",
                "byteorder",
                "bytes",
                "diesel1",
                "diesel2",
                "postgres",
                "rand",
                "rkyv",
                "rocket",
                "serde",
                "serde_json",
                "tokio-postgres",
            },
            {
                "diesel1": {"mysql", "postgres"},
                "diesel2": {"mysql", "postgres"},
                "rkyv": {"validation"},
                "serde_json": {"arbitrary_precision", "std"},
                "arrayvec": {"std"},
            },
            {
                "borsh": {"std"},
                "bytecheck": {"std"},
                "byteorder": {"std"},
                "bytes": {"std"},
                "rand": {"std"},
                "rkyv": {"std"},
                "serde": {"std"},
                "serde_json": {"std"},
            },
        ),
        # no default features
        ("rust_decimal-1.28.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "rustix-0.36.8.json",
            FeatureFlags(),
            {"default", "std", "use-libc-auxv", "io-lifetimes", "libc"},
            {"io-lifetimes", "libc"},
            dict(),
            dict(),
        ),
        # all features
        (
            "rustix-0.36.8.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "all-apis",
                "all-impls",
                "alloc",
                "cc",
                "compiler_builtins",
                "core",
                "fs",
                "fs-err",
                "io-lifetimes",
                "io_uring",
                "itoa",
                "libc",
                "libc_errno",
                "mm",
                "net",
                "once_cell",
                "os_pipe",
                "param",
                "process",
                "procfs",
                "rand",
                "runtime",
                "rustc-dep-of-std",
                "std",
                "termios",
                "thread",
                "time",
                "use-libc",
                "use-libc-auxv",
            },
            {"alloc", "cc", "compiler_builtins", "core", "io-lifetimes", "itoa", "libc", "libc_errno", "once_cell"},
            {"bitflags": {"rustc-dep-of-std"}, "io-lifetimes": {"fs-err", "os_pipe"}, "linux-raw-sys": {"rustc-dep-of-std"}},
            dict(),
        ),
        # no default features
        ("rustix-0.36.8.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + all-impls
        (
            "rustix-0.36.8.json",
            FeatureFlags(features=["all-impls"]),
            {"default", "std", "use-libc-auxv", "io-lifetimes", "libc", "all-impls", "os_pipe", "fs-err"},
            {"io-lifetimes", "libc"},
            {"io-lifetimes": {"fs-err", "os_pipe"}},
            dict(),
        ),
        # no default features + all-impls
        (
            "rustix-0.36.8.json",
            FeatureFlags(no_default_features=True, features=["all-impls"]),
            {"all-impls", "fs-err", "os_pipe"},
            {"io-lifetimes"},
            {"io-lifetimes": {"fs-err", "os_pipe"}},
            dict(),
        ),
        # default features
        ("serde-1.0.152.json", FeatureFlags(), {"default", "std"}, set(), dict(), dict()),
        # all features
        (
            "serde-1.0.152.json",
            FeatureFlags(all_features=True),
            {"default", "alloc", "derive", "serde_derive", "rc", "std", "unstable"},
            {"serde_derive"},
            dict(),
            dict(),
        ),
        # no default features
        ("serde-1.0.152.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + derive
        (
            "serde-1.0.152.json",
            FeatureFlags(features=["derive"]),
            {"default", "std", "derive", "serde_derive"},
            {"serde_derive"},
            dict(),
            dict(),
        ),
        # default features
        ("serde_derive-1.0.152.json", FeatureFlags(), {"default"}, set(), dict(), dict()),
        # all features
        ("serde_derive-1.0.152.json", FeatureFlags(all_features=True), {"default", "deserialize_in_place"}, set(), dict(), dict()),
        # no default features
        ("serde_derive-1.0.152.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "syn-1.0.107.json",
            FeatureFlags(),
            {"default", "derive", "parsing", "printing", "clone-impls", "proc-macro", "quote"},
            {"quote"},
            {"proc-macro2": {"proc-macro"}, "quote": {"proc-macro"}},
            dict(),
        ),
        # all features
        (
            "syn-1.0.107.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "clone-impls",
                "derive",
                "extra-traits",
                "fold",
                "full",
                "parsing",
                "printing",
                "proc-macro",
                "quote",
                "test",
                "visit",
                "visit-mut",
            },
            {"quote"},
            {"proc-macro2": {"proc-macro"}, "quote": {"proc-macro"}, "syn-test-suite": {"all-features"}},
            dict(),
        ),
        # no default features
        ("syn-1.0.107.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "time-0.3.17.json",
            FeatureFlags(),
            {"default", "std", "alloc"},
            set(),
            dict(),
            {"serde": {"alloc"}},
        ),
        # all features
        (
            "time-0.3.17.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "alloc",
                "formatting",
                "large-dates",
                "local-offset",
                "macros",
                "parsing",
                "quickcheck",
                "rand",
                "serde",
                "serde-human-readable",
                "serde-well-known",
                "std",
                "wasm-bindgen",
            },
            {"itoa", "libc", "num_threads", "time-macros", "quickcheck", "rand", "serde", "js-sys"},
            dict(),
            {"serde": {"alloc"}, "time-macros": {"formatting", "large-dates", "parsing", "serde"}},
        ),
        # no default features
        ("time-0.3.17.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + serde
        (
            "time-0.3.17.json",
            FeatureFlags(features=["serde"]),
            {"default", "std", "alloc", "serde"},
            {"serde"},
            dict(),
            {"serde": {"alloc"}, "time-macros": {"serde"}},
        ),
        # no default features + serde
        (
            "time-0.3.17.json",
            FeatureFlags(no_default_features=True, features=["serde"]),
            {"serde"},
            {"serde"},
            dict(),
            {"time-macros": {"serde"}},
        ),
        # default features
        (
            "tokio-1.25.0.json",
            FeatureFlags(),
            {"default"},
            set(),
            dict(),
            dict(),
        ),
        # all features
        (
            "tokio-1.25.0.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "bytes",
                "fs",
                "full",
                "io-std",
                "io-util",
                "libc",
                "macros",
                "memchr",
                "mio",
                "net",
                "num_cpus",
                "parking_lot",
                "process",
                "rt",
                "rt-multi-thread",
                "signal",
                "signal-hook-registry",
                "socket2",
                "stats",
                "sync",
                "test-util",
                "time",
                "tokio-macros",
                "tracing",
                "windows-sys",
            },
            {
                "bytes",
                "libc",
                "memchr",
                "mio",
                "num_cpus",
                "parking_lot",
                "signal-hook-registry",
                "socket2",
                "tokio-macros",
                "tracing",
                "windows-sys",
            },
            {
                "mio": {"os-poll", "os-ext", "net"},
                "windows-sys": {
                    "Win32_Foundation",
                    "Win32_Security",
                    "Win32_Storage_FileSystem",
                    "Win32_System_Console",
                    "Win32_System_Pipes",
                    "Win32_System_Threading",
                    "Win32_System_SystemServices",
                    "Win32_System_WindowsProgramming",
                },
            },
            dict(),
        ),
        # default features + signal
        (
            "tokio-1.25.0.json",
            FeatureFlags(features=["signal"]),
            {"default", "signal", "libc", "signal-hook-registry"},
            {"libc", "mio", "signal-hook-registry", "windows-sys"},
            {
                "mio": {"os-poll", "os-ext", "net"},
                "windows-sys": {"Win32_Foundation", "Win32_System_Console"},
            },
            dict(),
        ),
        # no default features + signal
        (
            "tokio-1.25.0.json",
            FeatureFlags(no_default_features=True, features=["signal"]),
            {"signal", "libc", "signal-hook-registry"},
            {"libc", "mio", "signal-hook-registry", "windows-sys"},
            {
                "mio": {"os-poll", "os-ext", "net"},
                "windows-sys": {"Win32_Foundation", "Win32_System_Console"},
            },
            dict(),
        ),
        # no default features
        (
            "tokio-1.25.0.json",
            FeatureFlags(no_default_features=True),
            set(),
            set(),
            dict(),
            dict(),
        ),
        # default features
        ("unicode-xid-0.2.4.json", FeatureFlags(), {"default"}, set(), dict(), dict()),
        # all features
        ("unicode-xid-0.2.4.json", FeatureFlags(all_features=True), {"default", "bench", "no_std"}, set(), dict(), dict()),
        # no default features
        ("unicode-xid-0.2.4.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features
        (
            "zbus-3.8.0.json",
            FeatureFlags(),
            {"default", "async-io", "async-executor", "async-task", "async-lock"},
            {"async-io", "async-executor", "async-task", "async-lock"},
            dict(),
            dict(),
        ),
        # all features
        (
            "zbus-3.8.0.json",
            FeatureFlags(all_features=True),
            {
                "default",
                "async-executor",
                "async-io",
                "async-lock",
                "async-task",
                "chrono",
                "gvariant",
                "lazy_static",
                "quick-xml",
                "serde-xml-rs",
                "time",
                "tokio",
                "tokio-vsock",
                "url",
                "uuid",
                "vsock",
                "windows-gdbus",
                "xml",
            },
            {
                "async-executor",
                "async-io",
                "async-lock",
                "async-task",
                "lazy_static",
                "quick-xml",
                "serde-xml-rs",
                "tokio",
                "tokio-vsock",
                "vsock",
            },
            {"zvariant": {"chrono", "gvariant", "time", "url", "uuid"}},
            dict(),
        ),
        # no default features
        ("zbus-3.8.0.json", FeatureFlags(no_default_features=True), set(), set(), dict(), dict()),
        # default features + tokio
        (
            "zbus-3.8.0.json",
            FeatureFlags(features=["tokio"]),
            {"default", "async-io", "async-executor", "async-task", "async-lock", "tokio", "lazy_static"},
            {"async-io", "async-executor", "async-task", "async-lock", "tokio", "lazy_static"},
            dict(),
            dict(),
        ),
        # no default features + tokio
        (
            "zbus-3.8.0.json",
            FeatureFlags(no_default_features=True, features=["tokio"]),
            {"tokio", "lazy_static"},
            {"tokio", "lazy_static"},
            dict(),
            dict(),
        ),
        # default features
        (
            "zoxide-0.9.0.json",
            FeatureFlags(),
            {"default"},
            set(),
            dict(),
            dict(),
        ),
        # all features
        (
            "zoxide-0.9.0.json",
            FeatureFlags(all_features=True),
            {"default", "nix-dev"},
            set(),
            dict(),
            dict(),
        ),
        # no default features
        (
            "zoxide-0.9.0.json",
            FeatureFlags(no_default_features=True),
            set(),
            set(),
            dict(),
            dict(),
        ),
    ],
    ids=short_repr,
)
def test_package_get_enabled_features_transitive(
    filename: str,
    flags: FeatureFlags,
    expected_enabled: Set[str],
    expected_optional: Set[str],
    expected_other: Dict[str, Set[str]],
    expected_conditional: Dict[str, Set[str]],
):
    metadata = load_metadata_from_resource(filename)
    enabled, optional_enabled, other_enabled, other_conditional = metadata.packages()[0].get_enabled_features_transitive(flags)

    assert enabled == expected_enabled
    assert optional_enabled == expected_optional
    assert other_enabled == expected_other
    assert other_conditional == expected_conditional


def test_feature_flags_invalid():
    with pytest.raises(ValueError) as exc:
        FeatureFlags(all_features=True, features=["default"])
    assert "Cannot specify both '--all-features' and '--features'." in str(exc.value)

    with pytest.raises(ValueError) as exc:
        FeatureFlags(no_default_features=True, all_features=True)
    assert "Cannot specify both '--all-features' and '--no-default-features'." in str(exc.value)


@pytest.mark.parametrize(
    "filename,optional,expected",
    [
        ("ahash-0.8.3.json", False, {"cfg-if", "once_cell"}),
        ("ahash-0.8.3.json", True, {"atomic-polyfill", "const-random", "getrandom", "serde"}),
        ("assert_cmd-2.0.8.json", False, {"bstr", "doc-comment", "predicates", "predicates-core", "predicates-tree", "wait-timeout"}),
        ("assert_cmd-2.0.8.json", True, {"concolor", "yansi"}),
        ("assert_fs-1.0.10.json", False, {"doc-comment", "globwalk", "predicates", "predicates-core", "predicates-tree", "tempfile"}),
        ("assert_fs-1.0.10.json", True, {"concolor", "yansi"}),
        ("autocfg-1.1.0.json", False, set()),
        ("autocfg-1.1.0.json", True, set()),
        ("bstr-1.2.0.json", False, {"memchr"}),
        ("bstr-1.2.0.json", True, {"once_cell", "regex-automata", "serde"}),
        ("cfg-if-1.0.0.json", False, set()),
        ("cfg-if-1.0.0.json", True, {"compiler_builtins", "core"}),
        ("clap-4.1.4.json", False, {"bitflags", "clap_lex"}),
        (
            "clap-4.1.4.json",
            True,
            {"backtrace", "clap_derive", "is-terminal", "once_cell", "strsim", "termcolor", "terminal_size", "unicase", "unicode-width"},
        ),
        (
            "gstreamer-0.19.7.json",
            False,
            {
                "bitflags",
                "cfg-if",
                "ffi",
                "futures-channel",
                "futures-core",
                "futures-util",
                "glib",
                "libc",
                "muldiv",
                "num-integer",
                "num-rational",
                "once_cell",
                "opt-ops",
                "paste",
                "pretty-hex",
                "thiserror",
            },
        ),
        ("gstreamer-0.19.7.json", True, {"serde", "serde_bytes"}),
        ("human-panic-1.1.0.json", False, {"backtrace", "os_info", "serde", "serde_derive", "toml", "uuid"}),
        ("human-panic-1.1.0.json", True, {"concolor", "termcolor"}),
        (
            "hyperfine-1.15.0.json",
            False,
            {
                "anyhow",
                "atty",
                "clap",
                "colored",
                "csv",
                "indicatif",
                "rand",
                "rust_decimal",
                "serde",
                "serde_json",
                "shell-words",
                "statistical",
                "thiserror",
                "once_cell",
                "libc",
                "nix",
                "winapi",
            },
        ),
        ("hyperfine-1.15.0.json", True, set()),
        ("libc-0.2.139.json", False, set()),
        ("libc-0.2.139.json", True, {"rustc-std-workspace-core"}),
        ("predicates-2.1.5.json", False, {"itertools", "predicates-core"}),
        ("predicates-2.1.5.json", True, {"concolor", "difflib", "float-cmp", "normalize-line-endings", "regex", "yansi"}),
        ("proc-macro2-1.0.50.json", False, {"unicode-ident"}),
        ("proc-macro2-1.0.50.json", True, set()),
        ("quote-1.0.23.json", False, {"proc-macro2"}),
        ("quote-1.0.23.json", True, set()),
        ("rand-0.8.5.json", False, {"rand_core"}),
        ("rand-0.8.5.json", True, {"log", "packed_simd", "rand_chacha", "serde", "libc"}),
        ("rand_core-0.6.4.json", False, set()),
        ("rand_core-0.6.4.json", True, {"getrandom", "serde"}),
        ("rust_decimal-1.28.0.json", False, {"arrayvec", "num-traits"}),
        (
            "rust_decimal-1.28.0.json",
            True,
            {
                "arbitrary",
                "borsh",
                "bytecheck",
                "byteorder",
                "bytes",
                "diesel1",
                "diesel2",
                "postgres",
                "rand",
                "rkyv",
                "rocket",
                "serde",
                "serde_json",
                "tokio-postgres",
            },
        ),
        ("rustix-0.36.8.json", False, {"bitflags", "linux-raw-sys", "libc", "libc_errno", "windows-sys"}),
        ("rustix-0.36.8.json", True, {"alloc", "compiler_builtins", "core", "io-lifetimes", "itoa", "libc", "libc_errno", "once_cell"}),
        ("serde-1.0.152.json", False, set()),
        ("serde-1.0.152.json", True, {"serde_derive"}),
        ("serde_derive-1.0.152.json", False, {"proc-macro2", "quote", "syn"}),
        ("serde_derive-1.0.152.json", True, set()),
        ("syn-1.0.107.json", False, {"proc-macro2", "unicode-ident"}),
        ("syn-1.0.107.json", True, {"quote"}),
        ("time-0.3.17.json", False, {"time-core"}),
        ("time-0.3.17.json", True, {"itoa", "quickcheck", "rand", "serde", "time-macros", "js-sys", "libc", "num_threads"}),
        ("tokio-1.25.0.json", False, {"pin-project-lite", "windows-sys"}),
        (
            "tokio-1.25.0.json",
            True,
            {
                "bytes",
                "memchr",
                "mio",
                "num_cpus",
                "parking_lot",
                "tokio-macros",
                "socket2",
                "tracing",
                "libc",
                "signal-hook-registry",
                "windows-sys",
            },
        ),
        ("unicode-xid-0.2.4.json", False, set()),
        ("unicode-xid-0.2.4.json", True, set()),
        (
            "zbus-3.8.0.json",
            False,
            {
                "async-broadcast",
                "async-recursion",
                "async-trait",
                "byteorder",
                "derivative",
                "dirs",
                "enumflags2",
                "event-listener",
                "futures-core",
                "futures-sink",
                "futures-util",
                "hex",
                "nix",
                "once_cell",
                "ordered-stream",
                "rand",
                "serde",
                "serde_repr",
                "sha1",
                "static_assertions",
                "tracing",
                "zbus_macros",
                "zbus_names",
                "zvariant",
                "uds_windows",
                "winapi",
            },
        ),
        (
            "zbus-3.8.0.json",
            True,
            {
                "async-executor",
                "async-io",
                "async-lock",
                "async-task",
                "lazy_static",
                "quick-xml",
                "serde-xml-rs",
                "tokio",
                "tokio-vsock",
                "vsock",
            },
        ),
        (
            "zoxide-0.9.0.json",
            False,
            {"anyhow", "askama", "bincode", "clap", "dirs", "dunce", "fastrand", "glob", "ouroboros", "serde", "nix", "which"},
        ),
        ("zoxide-0.9.0.json", True, set()),
    ],
    ids=short_repr,
)
def test_package_get_normal_dependencies(filename: str, optional: bool, expected: Set[str]):
    data = load_metadata_from_resource(filename)
    assert set(data.packages()[0].get_normal_dependencies(optional).keys()) == expected


@pytest.mark.parametrize(
    "filename,expected",
    [
        (
            "ahash-0.8.3.json",
            {
                "criterion",
                "fnv",
                "fxhash",
                "hashbrown",
                "hex",
                "no-panic",
                "rand",
                "seahash",
                "serde_json",
            },
        ),
        ("assert_cmd-2.0.8.json", {"escargot"}),
        ("assert_fs-1.0.10.json", set()),
        ("autocfg-1.1.0.json", set()),
        ("bstr-1.2.0.json", {"quickcheck", "ucd-parse", "unicode-segmentation"}),
        ("cfg-if-1.0.0.json", set()),
        ("clap-4.1.4.json", {"humantime", "rustversion", "shlex", "snapbox", "static_assertions", "trybuild", "trycmd", "unic-emoji-char"}),
        ("gstreamer-0.19.7.json", {"futures-executor", "gir-format-check", "ron", "serde_json"}),
        ("human-panic-1.1.0.json", set()),
        ("hyperfine-1.15.0.json", {"approx", "assert_cmd", "predicates", "tempfile"}),
        ("libc-0.2.139.json", set()),
        ("predicates-2.1.5.json", {"predicates-tree"}),
        ("proc-macro2-1.0.50.json", {"quote"}),
        ("quote-1.0.23.json", {"rustversion", "trybuild"}),
        ("rand-0.8.5.json", {"bincode", "rand_pcg"}),
        ("rand_core-0.6.4.json", set()),
        (
            "rust_decimal-1.28.0.json",
            {"bincode", "bytes", "criterion", "csv", "futures", "rand", "serde", "serde_json", "tokio", "version-sync"},
        ),
        (
            "rustix-0.36.8.json",
            {"flate2", "io-lifetimes", "libc", "libc_errno", "memoffset", "serial_test", "tempfile", "criterion", "ctor"},
        ),
        ("serde-1.0.152.json", {"serde_derive"}),
        ("serde_derive-1.0.152.json", {"serde"}),
        (
            "syn-1.0.107.json",
            {
                "anyhow",
                "automod",
                "flate2",
                "insta",
                "rayon",
                "ref-cast",
                "regex",
                "reqwest",
                "syn-test-suite",
                "tar",
                "termcolor",
                "walkdir",
            },
        ),
        ("time-0.3.17.json", {"quickcheck_macros", "rand", "serde", "serde_json", "serde_test", "time-macros", "trybuild", "criterion"}),
        (
            "tokio-1.25.0.json",
            {
                "async-stream",
                "futures",
                "mockall",
                "tempfile",
                "tokio-stream",
                "tokio-test",
                "wasm-bindgen-test",
                "loom",
                "rand",
                "proptest",
                "socket2",
                "mio-aio",
                "libc",
                "nix",
                "ntapi",
            },
        ),
        ("unicode-xid-0.2.4.json", {"criterion"}),
        ("zbus-3.8.0.json", {"async-std", "doc-comment", "futures-util", "ntest", "tempfile", "test-log", "tokio", "tracing-subscriber"}),
        ("zoxide-0.9.0.json", {"assert_cmd", "rstest", "rstest_reuse", "tempfile"}),
    ],
    ids=short_repr,
)
def test_package_get_dev_dependencies(filename: str, expected: Set[str]):
    data = load_metadata_from_resource(filename)
    assert set(data.packages()[0].get_dev_dependencies().keys()) == expected


@pytest.mark.parametrize(
    "filename,optional,expected",
    [
        ("ahash-0.8.3.json", False, {"version_check"}),
        ("ahash-0.8.3.json", True, set()),
        ("assert_cmd-2.0.8.json", False, set()),
        ("assert_cmd-2.0.8.json", True, set()),
        ("assert_fs-1.0.10.json", False, set()),
        ("assert_fs-1.0.10.json", True, set()),
        ("autocfg-1.1.0.json", True, set()),
        ("autocfg-1.1.0.json", False, set()),
        ("bstr-1.2.0.json", False, set()),
        ("bstr-1.2.0.json", True, set()),
        ("cfg-if-1.0.0.json", False, set()),
        ("cfg-if-1.0.0.json", True, set()),
        ("clap-4.1.4.json", False, set()),
        ("clap-4.1.4.json", True, set()),
        ("gstreamer-0.19.7.json", False, set()),
        ("gstreamer-0.19.7.json", True, set()),
        ("human-panic-1.1.0.json", False, set()),
        ("human-panic-1.1.0.json", True, set()),
        ("hyperfine-1.15.0.json", False, {"atty", "clap", "clap_complete"}),
        ("hyperfine-1.15.0.json", True, set()),
        ("libc-0.2.139.json", False, set()),
        ("libc-0.2.139.json", True, set()),
        ("predicates-2.1.5.json", False, set()),
        ("predicates-2.1.5.json", True, set()),
        ("proc-macro2-1.0.50.json", False, set()),
        ("proc-macro2-1.0.50.json", True, set()),
        ("quote-1.0.23.json", False, set()),
        ("quote-1.0.23.json", True, set()),
        ("rand-0.8.5.json", False, set()),
        ("rand-0.8.5.json", True, set()),
        ("rand_core-0.6.4.json", False, set()),
        ("rand_core-0.6.4.json", True, set()),
        ("rust_decimal-1.28.0.json", False, set()),
        ("rust_decimal-1.28.0.json", True, set()),
        ("rustix-0.36.8.json", False, set()),
        ("rustix-0.36.8.json", True, {"cc"}),
        ("serde-1.0.152.json", False, set()),
        ("serde-1.0.152.json", True, set()),
        ("serde_derive-1.0.152.json", False, set()),
        ("serde_derive-1.0.152.json", True, set()),
        ("syn-1.0.107.json", False, set()),
        ("syn-1.0.107.json", True, set()),
        ("time-0.3.17.json", False, set()),
        ("time-0.3.17.json", True, set()),
        ("tokio-1.25.0.json", False, {"autocfg"}),
        ("tokio-1.25.0.json", True, set()),
        ("unicode-xid-0.2.4.json", False, set()),
        ("unicode-xid-0.2.4.json", True, set()),
        ("zbus-3.8.0.json", False, set()),
        ("zbus-3.8.0.json", True, set()),
        ("zoxide-0.9.0.json", False, {"clap", "clap_complete", "clap_complete_fig"}),
        ("zoxide-0.9.0.json", True, set()),
    ],
    ids=short_repr,
)
def test_package_get_build_dependencies(filename: str, optional: bool, expected: Set[str]):
    data = load_metadata_from_resource(filename)
    assert set(data.packages()[0].get_build_dependencies(optional).keys()) == expected


@pytest.mark.parametrize(
    "filename,feature,expected",
    [
        ("ahash-0.8.3.json", None, "crate(ahash) = 0.8.3"),
        ("ahash-0.8.3.json", "default", "crate(ahash/default) = 0.8.3"),
        ("assert_cmd-2.0.8.json", None, "crate(assert_cmd) = 2.0.8"),
        ("assert_cmd-2.0.8.json", "default", "crate(assert_cmd/default) = 2.0.8"),
    ],
    ids=short_repr,
)
def test_package_to_rpm_dependency(filename: str, feature: Optional[str], expected: str):
    data = load_metadata_from_resource(filename)
    assert data.packages()[0].to_rpm_dependency(feature) == expected
