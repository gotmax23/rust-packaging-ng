import json
import logging
import subprocess
from typing import Dict, List, Set, Optional, Tuple

from cargo2rpm.semver import Comparator, Op, Version, VersionReq


class FeatureFlags:
    def __init__(self, all_features: bool = False, no_default_features: bool = False, features: List[str] = None):
        if features is None:
            features = []

        if all_features and features:
            raise ValueError("Cannot specify both '--all-features' and '--features'.")

        if all_features and no_default_features:
            raise ValueError("Cannot specify both '--all-features' and '--no-default-features'.")

        self.all_features = all_features
        self.no_default_features = no_default_features
        self.features = features

    def __repr__(self):
        parts = []

        if self.all_features:
            parts.append("all_features")
        if self.no_default_features:
            parts.append("no_default_features")
        if self.features:
            parts.append(f"features=[{', '.join(self.features)}]")

        if parts:
            string = ", ".join(parts)
            return f"[{string}]"
        else:
            return "[]"


class Dependency:
    def __init__(self, data):
        self._data = data

    def __repr__(self):
        return repr(self._data)

    def name(self) -> str:
        return self._data["name"]

    def req(self) -> str:
        return self._data["req"]

    def kind(self) -> Optional[str]:
        return self._data["kind"]

    def rename(self) -> Optional[str]:
        return self._data["rename"]

    def optional(self) -> bool:
        return self._data["optional"]

    def uses_default_features(self) -> bool:
        return self._data["uses_default_features"]

    def features(self) -> List[str]:
        return self._data["features"]

    def target(self) -> Optional[str]:
        return self._data["target"]

    def to_rpm(self, feature: Optional[str]) -> str:
        req = VersionReq.parse(self.req())
        return req.to_rpm(self.name(), feature)


class Target:
    def __init__(self, data):
        self._data = data

    def __repr__(self):
        return repr(self._data)

    def name(self) -> str:
        return self._data["name"]

    def kind(self) -> List[str]:
        return self._data["kind"]

    def crate_types(self) -> List[str]:
        return self._data["crate_types"]


class Package:
    def __init__(self, data):
        self._data = data

    def __repr__(self):
        return repr(self._data)

    def name(self) -> str:
        return self._data["name"]

    def version(self) -> str:
        return self._data["version"]

    def license(self) -> Optional[str]:
        return self._data["license"]

    def license_file(self) -> Optional[str]:
        return self._data["license_file"]

    def description(self) -> str:
        return self._data["description"]

    def dependencies(self) -> List[Dependency]:
        return [Dependency(dependency) for dependency in self._data["dependencies"]]

    def targets(self) -> List[Target]:
        return [Target(target) for target in self._data["targets"]]

    def features(self) -> Dict[str, List[str]]:
        return self._data["features"]

    def manifest_path(self) -> str:
        return self._data["manifest_path"]

    def rust_version(self) -> str:
        return self._data["rust_version"]

    def get_feature_names(self) -> Set[str]:
        return set(self.features().keys())

    def get_normal_dependencies(self, optional: bool) -> Dict[str, Dependency]:
        """
        Returns a dictionary that maps "normal" dependencies (i.e. not build- or dev-dependencies)
        from their possibly renamed name (i.e. how they can be referenced in feature dependencies)
        to the dependency objects themselves.
        """

        normal = filter(lambda d: d.kind() is None and d.optional() == optional, self.dependencies())
        return {d.rename() if d.rename() else d.name(): d for d in normal}

    def get_build_dependencies(self, optional: bool) -> Dict[str, Dependency]:
        """
        Returns a dictionary that maps build-dependencies from their possibly renamed name (i.e.
        how they can be referenced in feature dependencies) to the dependency objects themselves.
        """

        build = filter(lambda d: d.kind() == "build" and d.optional() == optional, self.dependencies())
        return {d.rename() if d.rename() else d.name(): d for d in build}

    def get_dev_dependencies(self) -> Dict[str, Dependency]:
        """
        Returns a dictionary that maps dev-dependencies from their possibly renamed name (i.e.
        how they can be referenced in feature dependencies) to the dependency objects themselves.
        """

        dev = filter(lambda d: d.kind() == "dev", self.dependencies())
        return {d.rename() if d.rename() else d.name(): d for d in dev}

    def to_rpm_dependency(self, feature: Optional[str]) -> str:
        ver = Version.parse(self.version())
        req = VersionReq([Comparator(Op.EXACT, ver.major, ver.minor, ver.patch, ver.pre)])
        return req.to_rpm(self.name(), feature)

    def is_bin(self) -> bool:
        for target in self.targets():
            if "bin" in target.kind():
                return True
        return False

    def is_lib(self) -> bool:
        """
        For purposes of packaging Rust crates as source-only packages, a
        "library" can only be a crate of type "lib" or "proc-macro".
        """

        for target in self.targets():
            if "lib" in target.kind() and "lib" in target.crate_types():
                return True
            if "proc-macro" in target.kind() and "proc-macro" in target.crate_types():
                return True
        return False

    def get_binaries(self) -> Set[str]:
        bins = set()
        for target in self.targets():
            if "bin" in target.kind():
                bins.add(target.name())
        return bins

    def get_enabled_features_transitive(self, flags: FeatureFlags) -> Tuple[Set[str], Set[str], Dict[str, Set[str]], Dict[str, Set[str]]]:
        # get names of all optional dependencies
        optional_names = set(self.get_normal_dependencies(True).keys()).union(set(self.get_build_dependencies(True).keys()))

        # collect enabled features of this crate
        enabled: Set[str] = set()
        # collect enabled optional dependencies
        optional_enabled: Set[str] = set()
        # collect enabled features of other crates
        other_enabled: Dict[str, Set[str]] = dict()
        # collect conditionally enabled features of other crates
        other_conditional: Dict[str, Set[str]] = dict()

        # process arguments
        feature_names = self.get_feature_names()

        if not flags.no_default_features and "default" not in flags.features and "default" in feature_names:
            enabled.add("default")

        if flags.all_features:
            for feature in feature_names:
                enabled.add(feature)

        for feature in flags.features:
            enabled.add(feature)

        # calculate transitive closure of enabled features
        while True:
            new = set()

            for feature in enabled:
                deps = self.features()[feature]

                for dep in deps:
                    # named optional dependency
                    if dep.startswith("dep:"):
                        name = dep.removeprefix("dep:")
                        optional_enabled.add(name)
                        continue

                    # dependency/feature
                    if "/" in dep and "?/" not in dep:
                        name, feat = dep.split("/")

                        # using "foo/bar" in feature dependencies implicitly
                        # also enables the optional dependency "foo":
                        if name in optional_names:
                            optional_enabled.add(name)

                        if name in other_enabled.keys():
                            other_enabled[name].add(feat)
                        else:
                            other_enabled[name] = {feat}
                        continue

                    # dependency?/feature
                    if "?/" in dep:
                        name, feat = dep.split("?/")
                        if name in other_conditional.keys():
                            other_conditional[name].add(feat)
                        else:
                            other_conditional[name] = {feat}
                        continue

                    if dep not in enabled:
                        new.add(dep)

            # continue until set of enabled "proper" features no longer changes
            if new:
                for feature in new:
                    enabled.add(feature)
            else:
                break

        return enabled, optional_enabled, other_enabled, other_conditional


class Metadata:
    def __init__(self, data):
        self._data = data

    def __repr__(self):
        return repr(self._data)

    @staticmethod
    def from_json(data: str) -> "Metadata":
        return Metadata(json.loads(data))

    @staticmethod
    def from_cargo(cargo: str, path: str) -> "Metadata":  # pragma nocover
        ret = subprocess.run(
            [
                cargo,
                "metadata",
                "--quiet",
                "--format-version",
                "1",
                "--offline",
                "--no-deps",
                "--manifest-path",
                path,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        ret.check_returncode()

        data = ret.stdout.decode()
        warn = ret.stderr.decode()

        if warn:
            logging.warning("'cargo metadata' subcommand returned warnings:")
            logging.warning(warn)

        return Metadata.from_json(data)

    def packages(self) -> List[Package]:
        return [Package(package) for package in self._data["packages"]]

    def target_directory(self) -> str:
        return self._data["target_directory"]

    def is_workspace(self) -> bool:
        return len(self.packages()) >= 2

    def is_bin(self) -> bool:
        for package in self.packages():
            if package.is_bin():
                return True
        return False

    def is_lib(self) -> bool:
        packages = self.packages()

        # do not report libs from workspaces until this is actually supported
        if len(packages) >= 2:
            return False

        for package in self.packages():
            if package.is_lib():
                return True
        return False

    def get_binaries(self) -> Set[str]:
        bins = set()
        for package in self.packages():
            bins.update(package.get_binaries())
        return bins
