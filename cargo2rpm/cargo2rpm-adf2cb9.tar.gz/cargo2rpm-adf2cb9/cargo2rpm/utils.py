import importlib.resources

from cargo2rpm.metadata import Metadata


def load_metadata_from_resource(filename: str) -> Metadata:
    data = importlib.resources.files("cargo2rpm.testdata").joinpath(filename).read_text()
    return Metadata.from_json(data)


def short_repr(obj) -> str:
    s = repr(obj)
    if len(s) >= 22:
        return s[0:22] + ".."
    else:
        return s
