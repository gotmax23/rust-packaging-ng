from cargo2rpm.cli import get_args, get_feature_from_subpackage, get_cargo_toml_paths_from_stdin
from cargo2rpm.metadata import Metadata, FeatureFlags
from cargo2rpm.rpm import buildrequires, requires, provides
from cargo2rpm.semver import Version


CARGO = "cargo"


def main():
    args = get_args()

    # check if path argument is present when required
    if not args.path and args.action in {"buildrequires", "name", "version", "is-lib", "is-bin"}:
        print("Missing '--path' argument.")
        exit(1)

    match args.action:
        case "buildrequires":
            metadata = Metadata.from_cargo(CARGO, args.path)
            if metadata.is_workspace():
                print("Generating BuildRequires for cargo workspaces is not yet supported.")
                exit(1)

            # parse command line arguments into FeatureFlags
            features = args.features.split(",") if args.features else None
            flags = FeatureFlags(
                all_features=args.all_features,
                no_default_features=args.no_default_features,
                features=features,
            )

            brs = buildrequires(metadata.packages()[0], flags, args.with_check)
            for item in sorted(brs):
                print(item)
            exit(0)

        case "requires":
            paths = {args.path} if args.path else get_cargo_toml_paths_from_stdin()

            for path in paths:
                metadata = Metadata.from_cargo(CARGO, path)
                if metadata.is_workspace():
                    print("Cannot generate Requires for crates from a cargo workspace.")
                    exit(1)

                feature = get_feature_from_subpackage(args.feature) if args.subpackage else args.feature

                items = requires(metadata.packages()[0], feature)
                for item in sorted(items):
                    print(item)
            exit(0)

        case "provides":
            paths = {args.path} if args.path else get_cargo_toml_paths_from_stdin()

            for path in paths:
                metadata = Metadata.from_cargo(CARGO, path)
                if metadata.is_workspace():
                    print("Cannot generate Provides for crates from a cargo workspace.")
                    exit(1)

                feature = get_feature_from_subpackage(args.feature) if args.subpackage else args.feature

                print(provides(metadata.packages()[0], feature))
            exit(0)

        case "name":
            metadata = Metadata.from_cargo(CARGO, args.path)
            if metadata.is_workspace():
                print("Cannot determine crate name from a cargo workspace.")
                exit(1)

            print(metadata.packages()[0].name())
            exit(0)

        case "version":
            metadata = Metadata.from_cargo(CARGO, args.path)
            if metadata.is_workspace():
                print("Cannot determine crate version from a cargo workspace.")
                exit(1)

            print(metadata.packages()[0].version())
            exit(0)

        case "is-lib":
            metadata = Metadata.from_cargo(CARGO, args.path)
            if metadata.is_lib():
                print("1", end="")
            else:
                print("0", end="")
            exit(0)

        case "is-bin":
            metadata = Metadata.from_cargo(CARGO, args.path)
            if metadata.is_bin():
                print("1", end="")
            else:
                print("0", end="")
            exit(0)

        case "semver2rpm":
            print(Version.parse(args.version).to_rpm())
            exit(0)

        case "rpm2semver":
            print(str(Version.from_rpm(args.version)))
            exit(0)

        case _:
            print("Unknown action.")
            exit(1)


if __name__ == "__main__":
    main()
